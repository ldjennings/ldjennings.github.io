#pragma once

/* These are anything that needs to be known globably by the Atmega, but not the ESP32*/

#include <HC-SR04.h>
#include <LSM6.h>
#include <openmv.h>
#include <IRDirectionFinder.h>
#include <Sharp-IR.h>
#include <Chassis.h>

#define IR_EMITTER_PIN 11 //purely a reminder to us
#define SHARPIR_PIN A0

static SharpIR proximity_Sensor(SHARPIR_PIN);
static OpenMV camera;
static IRDirectionFinder irFinder;

static bool isWallFollowing = false;