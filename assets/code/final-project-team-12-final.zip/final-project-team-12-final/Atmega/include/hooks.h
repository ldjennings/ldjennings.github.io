#pragma once
#include <globals.h>
#include "shared-structs.h"
#include "romi-constants.h"

/*  This class holds the function implementations for the shared functions between the Atmega and ESP32.
    These functions handle low level behavior like polling sensors, updating kinematics & motor speeds.*/

float lastRF = CELL_LENGTH/2.0;

/* Motor Functions */

void setMotorEfforts(uint16_t left, uint16_t right) {
    chassis.setMotorEfforts(left, right);
}

void setMotorTargetSpeeds(float left, float right) {
    // Serial.println("Setting Motor Target Speeds: " + String(left) + " " + String(right));
    chassis.setMotorTargetSpeeds(left, right);
}

void setWheelTargetSpeeds(float left, float right) {
    // Serial.println("Setting Wheel Target Speeds: " + String(left) + " " + String(right));
    chassis.setWheelTargetSpeeds(left, right);
}

/* Sensor Updates */

DistanceReading getSharpDistance() {
    DistanceReading dist;
    dist.valid = proximity_Sensor.getDistance(dist.value);
    return dist;
}

DistanceReading getHCSR04Distance() {
    hc_sr04.sendPingIfReady();
    DistanceReading dist;
    dist.valid = hc_sr04.getDistance(dist.value);
    if(dist.value > (lastRF + 2.0*CELL_LENGTH)) {
        dist.valid = false;
    } else {
        lastRF = dist.value;
    }
    return dist;
}

IRFinderReading getIRFinderReading() {
    // Serial.println("Get IRFinder Dist...");
    irFinder.requestPosition();
    IRFinderReading reading;
    reading.valid = irFinder.available();
    //if data is not available, return invalid reading. 2 flags for this, valid = 0 & point.y = 1023
    if(!reading.valid) {
        reading.valid = 0;
        reading.points[0].x = 512;
        reading.points[0].y = 1023; 
        return reading;
    }
    IRPoint pt = irFinder.ReadPoint(0);
    if(pt.y != 1023) {
        // Serial.println("x " + String(pt.x) + ", y " + String(pt.y));
        reading.points[0].x = pt.x;
        reading.points[0].y = pt.y;
        return reading;
    }
    else {
        reading.valid = 0;
        return reading;
    }
}

CameraReading getCameraReading() {
    Serial.println("Get Camera Reading...");
    CameraReading c;
    c.foundReading = camera.getTagCount() > 0;
    if(c.foundReading) {
        AprilTagDatum tag;
        camera.readTag(tag);
        c.info = {.header = tag.header, .checksum = tag.checksum, .id = tag.id, .pos = {.x = tag.cx, .y = tag.cy}, .dim = {.x = tag.w, .y = tag.h}, .rot = tag.rot};
    }
    return c;
}

/* Kinematic Methods */

Pose getPoseEstimate() {
    Pose2D r = chassis.getCurrentPose();
    return Pose{.pos = {.x = r.x, .y = r.y}, .angle = r.theta, .pitch = chassis.getPitch()};
}

void resetPoseEstimate() {
    // Serial.println("Reset Pose Est.");
    chassis.setPose(CELL_LENGTH/2.0f, CELL_LENGTH/2.0f, 0.0f);
}

void setPose(float x, float y) {
    chassis.setPose(x, y, 0);
}

/*  Helper function for emitting an IR code
    This function takes an 8 bit unsinged integer and transmits each bit via an IR emitter on pin 11 using NEC encoding */

void sendCodeHelper(uint8_t signal) {
  for(int i = 0; i < 8; i++) {
    /* Sending bits in Little-Endian */
    uint8_t curSignal = signal & 0x01; 

    chassis.togglePulse(true);
    delayMicroseconds(562); //562

    // NEC encoding defines a 0 as a 562 leading pulse followed by 1.687ms space of low

    if(curSignal) { 
      chassis.togglePulse(false);
      delayMicroseconds(1687);
    }
    else {
      chassis.togglePulse(false);
      delayMicroseconds(562);
    }
    /* right-shift to have next bit to send be the LSB */
    signal = signal >> 1; 
  }
}

/* Function uses an IR Emitter connected to pin 11 to send an IR code in NEC format
    This function handles full NEC encoding including a preamble, pause, address + checksum, code+checksum and the final bit*/

void sendCode(uint8_t address, uint8_t code) {
  //first send 9ms leading pulse followed by 4.5 space trigger wake up procedure
  //Serial.println("started sending");
  chassis.togglePulse(true);
  delayMicroseconds(9000);
  chassis.togglePulse(false);
  delayMicroseconds(4500);

  sendCodeHelper(address);
  sendCodeHelper(~address);

  sendCodeHelper(code);
  sendCodeHelper(~code);

  // one last pulse to signal the end of communication
  chassis.togglePulse(true);
  delayMicroseconds(562);
  chassis.togglePulse(false);
}