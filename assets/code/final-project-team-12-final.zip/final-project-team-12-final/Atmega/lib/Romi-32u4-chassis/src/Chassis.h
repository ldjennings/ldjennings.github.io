#pragma once

#include <Arduino.h>
#include <Romi32U4Motors.h>
#include <romi-constants.h>

struct Pose2D
    {
        float x;
        float y;
        float theta;
    };

class Chassis
{
protected:
    //parameters -- these will need to be updated after you do experiments in lab 3
    float wheel_track = WHEEL_TRACK; //cm
    float wheel_diam = WHEEL_DIAM; //cm
    float ticks_per_rotation = TICKS_PER_ROT; 
    float cmPerEncoderTick = 3.1416 * wheel_diam / ticks_per_rotation;
    float robotRadius = wheel_track / 2.0;
    float pitchSensitivity = PITCH_SENS;
    float timeStep = IMU_TIMESTEP;
    const float KAPPA = 0.2;

    

    Pose2D position;
    float pitchAngle = 0;
    float bias = 0;
public:
    uint8_t readyToPID = 0;

    Chassis(void);

    void init(void);
    void loop(void);
    void update(void);
    void updatePose(void);
    void updatePitch(void);
    bool isMoving(void);
    void setPose(float, float, float);
    Pose2D& getCurrentPose();
    float getPitch();
    void togglePulse(bool);

    void setMotorEfforts(int16_t left, int16_t right) 
        {leftMotor.setMotorEffort(left); rightMotor.setMotorEffort(right);}

    void setMotorTargetSpeeds(float leftTicksPerInterval, float rightTicksPerInterval);

    void setWheelTargetSpeeds(float leftCMperS, float rightCMperS); 

    void moveToPose(Pose2D destPose);
};

extern Chassis chassis;