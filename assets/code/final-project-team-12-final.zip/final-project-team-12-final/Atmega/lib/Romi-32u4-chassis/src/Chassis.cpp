#include <Arduino.h>
#include <Chassis.h>
#include <Romi32U4Motors.h>
#include <LSM6.h>

// We'll declare motors as global to make the ISRs happier, but we'll put them in Chassis.cpp
// to keep things organized

LeftMotor leftMotor;
RightMotor rightMotor;

LSM6 imu;

Chassis::Chassis(void) {}

/*
    Set the wheel target speed, in CM/s

    @param leftCMperS Left wheel speed, CM/s
    @param rightCMperS Right wheel speed, CM/s

*/
void Chassis::setWheelTargetSpeeds(float leftCMperS, float rightCMperS) 
{
    setMotorTargetSpeeds((leftCMperS / cmPerEncoderTick) * .016,  (rightCMperS / cmPerEncoderTick) * .016);
}

/*
    Initialize timer interrupts for motors, and set pose to 0.
*/
void Chassis::init(void)
{  
    noInterrupts(); //disable interupts while we mess with the Timer4 registers
  
    //sets up timer 4
    TCCR4A = 0x00; //disable some functionality -- no need to worry about this
    TCCR4B = 0x0B; //sets the prescaler -- look in the handout for values
    TCCR4C = 0x04; //toggles pin 6 at the timer frequency
    TCCR4D = 0x00; //normal mode

    /*
    * EDIT THE LINE BELOW WITH YOUR VALUE FOR TOP
    */

    OCR4C = 249;   //TOP goes in OCR4C 

    TIMSK4 = 0x04; //enable overflow interrupt

    interrupts(); //re-enable interrupts

    // init the motors
    Romi32U4Motor::init();

    position.x = 0;
    position.y = 0;
    position.theta = 0;

    if (!imu.init())
        {
        // Failed to detect the LSM6.
        while(1)
        {
        Serial.println(F("Failed to detect the LSM6. Just smash that reset button."));
        delay(100);
        }
        }
}

/*
    Call all relevant periodic functions for the chassis class.
*/
void Chassis::loop(void)
{
    if(readyToPID)
    {
        if(readyToPID > 1) Serial.println("Missed update in Chassis::loop()");
        
        update();
        updatePose();
        readyToPID = 0;
    }
        updatePitch();
}

/*
    Update motors. Call periodically.
*/
void Chassis::update(void)
{
    leftMotor.update();
    rightMotor.update();
}

/*
    Resets the pose to the center of the 0th cell. (bottom left.)
*/
void Chassis::setPose(float x, float y, float theta) {
    position.x = x;
    position.y = y;
    position.theta = theta;
}

/* 
    Updates the robot's pose using second order forward kinematics estimation.

    Updates wrt global reference frame, +X = forward, +Y = left.
*/
void Chassis::updatePose() {
    float newTheta, thetaStar, right_Dist, left_Dist, avg_Dist;

    right_Dist = rightMotor.speed * cmPerEncoderTick;
    left_Dist = leftMotor.speed * cmPerEncoderTick;

    avg_Dist = (right_Dist+ left_Dist) / 2.0;

    newTheta = position.theta + ((right_Dist-left_Dist) / wheel_track);
    thetaStar = (newTheta + position.theta) / 2.0;

    position.x = position.x + cos(thetaStar) * avg_Dist;
    position.y = position.y + sin(thetaStar) * avg_Dist;
    position.theta = newTheta;  
    
    
    #ifdef POSE_DEBUG

        float angle = (180 / M_PI) * position.theta;
        Serial.print("X: ");
        Serial.print(position.x);
        Serial.print("\t");
        Serial.print("Y: ");
        Serial.print(position.y);
        Serial.print("\t");
        Serial.print("Angle: ");
        Serial.print(angle);
        Serial.print("\t");
        Serial.print("R_Dist: ");
        Serial.print(right_Dist);
        Serial.print("\t");
        Serial.print("L_Dist: ");
        Serial.print(left_Dist);
        Serial.print("\n");
    #endif

}

void Chassis::updatePitch() {
    if(imu.getStatus() & 0x01)  {

      float predictionAngle,observedAngle;
      
      imu.readAcc();
      imu.readGyro();

      float accel_X = imu.a.x - 456.5; // IMU reading - measured bias 
      float accell_Z = imu.a.z - 492.2;// IMU reading - measured bias 

      /* we make a prediction step from the gyro and compare that to the observed angle from the accelerometer */
      predictionAngle = pitchAngle + timeStep * pitchSensitivity* ((float)(imu.g.y) - bias); //in angles
      observedAngle = (180.0 / 3.1416) * atan2(accel_X , accell_Z); //atan2 returns in radians, so we convert to an angle to work with the prediction angle

      pitchAngle = predictionAngle + KAPPA * (observedAngle - predictionAngle); //complementary filter 

      bias = bias - 0.01 * (observedAngle-predictionAngle) * (1.0 /( timeStep * pitchSensitivity));
      #ifdef PITCH_DEBUG

        // float degrees = pitchAngle * 180.0 / 3.1416;

        // Serial.print("Millis: ");
        // Serial.print(millis());

        Serial.print(" predictionAngle: ");
        Serial.print(predictionAngle);
        Serial.print(" observedAngle: ");
        Serial.print(observedAngle);
        Serial.print(" pitchAngle: ");
        Serial.print(pitchAngle);
        // Serial.print(" bias: ");
        // Serial.print(bias/10);
        Serial.print('\n');

        //accelerometer
        // Serial.print("X: ");
        // Serial.print(imu.a.x);
        // Serial.print(" Y: ");
        // Serial.print(imu.a.y);
        // Serial.print(" Z: ");
        // Serial.print(imu.a.z);

        //gyro
        // Serial.print("X: ");
        // Serial.print(imu.g.x);
        // Serial.print(" Y: ");
        // Serial.print(imu.g.y);
        // Serial.print(" Z: ");
        // Serial.print(imu.g.z);

        
      #endif
    }

    return;
}

/*
    Set motor target speeds, in encoder ticks

    @param leftTicksPerInterval speed for the left motor, in ticks/encoder interval
    @param rightTicksPerInterval speed for the right motor, in ticks/encoder interval
*/
void Chassis::setMotorTargetSpeeds(float leftTicksPerInterval, float rightTicksPerInterval)
{
    leftMotor.setTargetSpeed(leftTicksPerInterval);
    rightMotor.setTargetSpeed(rightTicksPerInterval);
}

/*
    Return if any wheel is moving.

    @returns true if any wheels are moving.
*/
bool Chassis::isMoving() {
    abs(leftMotor.getSpeed()) > 0 || abs(rightMotor.getSpeed()) > 0;
    return true;
}

/*
    Return robot pose, wrt global reference frame.
*/
Pose2D& Chassis::getCurrentPose() {
    return this->position;
}

float Chassis::getPitch() {
    return pitchAngle;
}

void Chassis::togglePulse(bool enable) {
    Romi32U4Motor::togglePulse(enable);
}

/*
    Move the Robot to a destination pose in the global reference frame.

    @param targetPose The destination pose, with respect to the global reference frame.
*/
void Chassis::moveToPose(Pose2D targetPose) {

    // To avoid singularity problems at 0/360deg, transform the vectors into local frame of reference to figure out the difference.
    // This is done so that the singularity will always be directly behind the robot, meaning we don't have to worry about it
    //    (a difference in angle will be centered on the forward direction.)

    float cX = chassis.getCurrentPose().x;
    float cY = chassis.getCurrentPose().y;
    float cT = chassis.getCurrentPose().theta;

    float dX = cX - targetPose.x;
    float dY = cY - targetPose.y;

    // Rotation matrix calculation.

    float tX = -dY * cosf(cT) + dX * sinf(cT);
    float tY = -dY * sinf(cT) - dX * cosf(cT);

    // Now that tX and tY are wrt local ref. frame, we can easily find the angle difference.

    float angleDiff =  atan2f(tX, tY);

    // Calculate linear distance for forward motor speed prop. control.

    float euclidDist = sqrtf(powf(dX, 2) + powf(dY, 2));

    // Constrain speeds so we don't go super fast and miss encoder counts or something
    float speed = constrain(euclidDist * LINEAR_KP, -10.0, 10.0);
    float angSpeed = constrain((angleDiff * HEADING_KP), -5.0, 5.0);

    // Just add the linear speed and angular speed together
    chassis.setWheelTargetSpeeds(speed - angSpeed, speed + angSpeed);
}

/*
 * ISR for timing. On overflow, it takes a 'snapshot' of the encoder counts and raises a flag to let
 * the main program it is time to execute the PID calculations.
 */
ISR(TIMER4_OVF_vect)
{
  //Capture a "snapshot" of the encoder counts for later processing
  leftMotor.calcEncoderDelta();
  rightMotor.calcEncoderDelta();

  chassis.readyToPID++;
}