#include <Arduino.h>
#include <shared-functions.h>
#include <tinyrpc.h>
#include <globals.h>
#include <romi-constants.h>

/* Declaration of IR_Reciever and chassis objects */
Chassis chassis;

float lastHRDist, HRdelta, distance, sum, lastDiff;

/*
Methodology: The Atmega32u4 is a very underpowered MCU compared to the ESP32. Therefore, it is suited to do the low level control of the hardware, 
but not very suited to do all the complex logic that we would like to do for our robotic algorithms. Therefore, the functions implemented here will
do all low level control of hardware and then be called via RPC from the ESP32.
*/

void setup() {
  Serial.begin(115200);

  /* Init RPC */
  Serial1.begin(115200);
  TinyRPC::init(&Serial1);

  chassis.init();
  hc_sr04.init();
  irFinder.begin();

  chassis.setPose(START_X, -START_Y, 0);

  Serial.println("End Setup...");
}

void loop() {

  chassis.loop();

  TinyRPC::listenServe();
}