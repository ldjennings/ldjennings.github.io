#ifndef _TINYRPC_H
#define _TINYRPC_H

#include <tinyrpc-macros.h>
#include <Arduino.h>

namespace TinyRPC {
    typedef uint8_t* RPCArgPtr;
    typedef void(*RPCFStub)(RPCArgPtr);
    typedef struct RPCStubMap {
        const RPCFStub stub;
        const uint8_t nargs;
    } RPCStubMap;

    void init(HardwareSerial* serial);

    #ifdef TINYRPC_SERVER

        void listenServe();
        void ret_stub(uint8_t nbret, void* v);

        /* 
        Since we want to optimize compile sizes as much as possible, we won't use templates for the function stubs
        Templating the stubs would mean that the compiler would generate a new function for every type we send over 
        the network, while macros allow us to just use one.
        
        Also, Arduino has no STL, so it makes templated types a pain to work with beyond the basics.

        check tinyrpc-macros.h for an explanation of the macro magic.
        */

        #define rt_10(ret, name, ...) ((ret(*)(__VA_ARGS__))name)MAP(fargs, (__VA_ARGS__)); /* If the return type is void, and there are arguments, this stub is called. */
        #define rt_00(ret, name, ...) ret x = ((ret(*)(__VA_ARGS__))name)MAP(fargs, (__VA_ARGS__)); TinyRPC::ret_stub(sizeof(ret), (void*)&x); /* If the return type is not void, and there are arguments, this stub is called */
        #define rt_11(ret, name, ...) ((ret(*)(__VA_ARGS__))name)(); /* If the return type is void, and there are no arguments, this stub is called. */
        #define rt_01(ret, name, ...) ret x = ((ret(*)(__VA_ARGS__))name)(); TinyRPC::ret_stub(sizeof(ret), (void*)&x); /* If the return type is not void, and there are arguments, this stub is called */

        #define exp_size_0(...) 0 MAPT_XX(+ sizeof, (__VA_ARGS__)) /* if we have any arguments, we can get the sum of the size of them with this */
        #define exp_size_1(...) 0 /* if we don't have any arguments, this is just zero */

        #define RPC_LIST_START // We don't need these for anything, but if we define them to nothing, we maintain cross-compatibility between the client and server
        #define RPC_LIST_END

        #define RPC_FUNC(ret, name, ...)                                                                                \
            void __rpcstub__ ##name(TinyRPC::RPCArgPtr fargs) { GLUE(GLUE(rt_, IS_VOID(_##ret)), IS_VOID(GLUE(_,FIRST(__VA_ARGS__))))(ret, name, __VA_ARGS__) }  /* Select the correct stub from above given the fcn signature */ \
            static const TinyRPC::RPCStubMap stubentry_##name                                                           \
            __attribute((used, section("trpc_stubs"))) = {                                                              /* add the StubMap entry to the section "trpc_stubs" so we can resolve it at runtime */ \
                .stub = __rpcstub__ ##name,                                                                             \
                .nargs = GLUE(exp_size_, IS_VOID(GLUE(_, FIRST(__VA_ARGS__))))(__VA_ARGS__) };

    #endif

    #ifdef TINYRPC_CLIENT
        extern bool call_mtx;  // mutex to check if we have a call out to the atmega
        extern void* last_p;   // the last promise we made
        extern uint8_t last_s; // we need to save the last size globally in case the promise goes out of scope before we can resolve it.

        void ptx(uint8_t id, uint8_t nbargs, ...);
        void recvRet(uint8_t s, void* retval);
        void resolve_last();


        /* 
            Promise kind of has weird semantics because since the atmega can only execute 1 thing at a time,
            we can only have at most 1 unresolved promise at a time. But, for our purposes, it's Good Enough (TM)
        */

        template <typename T>
        class Promise {
        private:
            T value;

        public:
            Promise<T>() {
                last_p = this;
                last_s = sizeof(T);
            }

            ~Promise<T>() {
                if(last_p == this)
                    last_p = nullptr; // we've gone out of scope, so we need to indicate that this is no longer a valid promise to write to.
            }

            T& await() {
                if(last_p == this && last_s == 0) // If this was the last promise, and size is 0, that means we've already been resolved.
                    return (T&)(this->value);

                TinyRPC::recvRet(sizeof(T), &value);
                return (T&)(this->value);
            };
        };

        #define pt_v_nv(id, ret, nbargs, ...)  /* stub called to transmit a void returning function with nonvoid arguments */ \
            TinyRPC::ptx(id, nbargs, __VA_ARGS__);

        #define pt_nv_nv(id, ret, nbargs, ...)  /* stub called to transmit a nonvoid returning function with nonvoid arguments */ \
            TinyRPC::ptx(id, nbargs, __VA_ARGS__); \
            TinyRPC::Promise<ret> x;               \
            TinyRPC::call_mtx = true;              \
            return x;                              \

        #define pt_v_v(id, ret, nbargs, ...)  /* stub called to transmit a void returning function with void arguments */ \
            TinyRPC::ptx(id, nbargs);

        #define pt_nv_v(id, ret, nbargs, ...)  /* stub called to transmit a nonvoid returning function with void arguments */ \
            TinyRPC::ptx(id, nbargs);               \
            TinyRPC::Promise<ret> x;               \
            TinyRPC::call_mtx = true;              \
            return x;                              \

        #define RPC_FUNC_PROXY10(ret, name, ...) /* since we have to use token concat to determine the void-ness of stuff, we have these proxy macros to expand the ones above. */ \
        void name(FN_DEF_EXPAND((__VA_ARGS__))) {       \
            pt_v_nv(__COUNTER__-__TRPC_COUNTER_BASE, ret, VARCOUNT(__VA_ARGS__), PTX_EXPAND((__VA_ARGS__)))    \
        }

        #define RPC_FUNC_PROXY00(ret, name, ...) \
        TinyRPC::Promise<ret> name(FN_DEF_EXPAND((__VA_ARGS__))) {       \
            pt_nv_nv(__COUNTER__-__TRPC_COUNTER_BASE, ret, VARCOUNT(__VA_ARGS__), PTX_EXPAND((__VA_ARGS__))) \
        }

        #define RPC_FUNC_PROXY11(ret, name, ...) \
        void name() {       \
            pt_v_v(__COUNTER__-__TRPC_COUNTER_BASE, ret, 0)    \
        }

        #define RPC_FUNC_PROXY01(ret, name, ...) \
        TinyRPC::Promise<ret> name() {       \
            pt_nv_v(__COUNTER__-__TRPC_COUNTER_BASE, ret, 0) \
        }


        #define RPC_LIST_START                                /* put all our generated rpc functions in a single namespace (and __COUNTER__ is a compiler macro that increments every time defined) */ \
            const int __TRPC_COUNTER_BASE = __COUNTER__;      /* __COUNTER__ isn't guarenteed to start at 0 since other librarys might also use it, so we save the value at the start of our list */   \
            namespace RPC {                                   /* (fun fact, in this particular program, __COUNTER__ starts at 28 when you build it for the esp32) */

        #define RPC_LIST_END                                \
            };

        #define RPC_FUNC(ret, name, ...) /* Expand and invoke the above macros to create function definitions and stubs for all our RPC functions */ \
            inline GLUE(GLUE(RPC_FUNC_PROXY, IS_VOID(_ ##ret)), IS_VOID(GLUE(_, FIRST(__VA_ARGS__))))(ret, name, __VA_ARGS__)
    #endif

}

#endif