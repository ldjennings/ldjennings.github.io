# TinyRPC Library Readme

### What?

TinyRPC is the library we wrote to facilitate communication between the two microcontrollers. At its core, it simply allows for networked function calls over UART, however there is a layer of abstraction over these function calls that allows integration to be seamless between the two devices, while still allowing them to run async from one another when desired.

### Why?

We found ourselves running out of flash memory space on the Atmega32U4. Since we wanted to have some more advanced logic for the robots to facillitate things like mapping, pathfinding, and bonus objectives, we decided to put all the high level logic on the ESP-32, which is much more powerful than the Atmega, and leave the Atmega to do the things it was suited to, like low-level control of peripherals. We wrote a library for two reasons; 1, because it provides stability and reliability - we don't have to worry about writing seperate uart send and recieve functions for each operation we want to do, and we can quickly iterate and change the function definitions without bothering to change any of the lower level UART functionality. It also provides some utilties like a simple checksum to reject noise on the uart bus, like that that might happen if one of the devices restarts. The other reason was because it was a fun little project :)

### How?

At its core, the tinyRPC library is very simple. A device is either a server (in this case, the Atmega32U4) that serves function calls over the network (in this case, UART), or it is a client (the ESP32) that can send call requests to the server, and, optionally, recieve data back. 

The functionality for this send and recieve is compiled into the code at compile time - On the server, a listener is started, which listens to UART and dispatches function calls that come on. On the client, a header file is made available for include that automatically compiles the server's function definitions into function stubs on the client, which then use the UART to dispatch function calls. In the end, everything is mostly seamless. A complete function definition might look something like this:

On the Atmega:

```c
float myCoolFunction(uint8_t myInt, uint8_t myFloat) {
    // do some stuff
    return 1234.5678;
}
```

In a shared header somewhere:
```c
RPC_FUNC(float, myCoolFunction, uint8_t, uint8_t)
```

On the ESP32
```c
void main() {
    // my logic
    ...
    float ret = myCoolFunction(1, 2).await();

    // ... do stuff with ret
}
```

The await keyword indicates that we would like to wait to resolve the function's return value immediately. By default, a function returns a "promise" which should be familiar to anyone who has done any asyncronous processing before. It means that on the ESP-32, we can do processing in between asking the Atmega to do something, and waiting for it to respond. For example, we could do something like:

```c
void main() {
    // my logic
    ...
    Promise<float> myPromise = myCoolFunction(1, 2);

    // do other stuff

    // if the atemga responded some time before now, this returns immediately. 
    // Otherwise, we will wait for the response.
    float x = myPromise.await();
}
```

TinyRPC also supports some other stuff like automatic serialization of custom datatypes. This means that you can use custom structs, for example, as long as the struct definition is provided to both devices. I.E:

```c
<shared.h>

typedef struct myStruct {
    float a;
    float b;
    uint16_t c;
    uint8_t d;
} myStruct;

RPC_FUNC(myStruct, myStructFunction, uint8_t, float, /* ...whatever */)
```

`myStructFunction` on the ESP-32 would then return a type of `myStruct`, and you would return a `myStruct` struct from the corresponding Atmega `myStructFunction`.

Essentially, the goal of the library was to make the semantics for calling remote functions on a different device as close as possible to calling normal functions that you would normally write in c.

The implementation of the UART and most of the bulk of the library is contained inside of `tinyrpc.cpp`. `tinyrpc.h` and `tinyrpc-macros.h` contain the macro magic that make it possible to seamlessly compile and resolve the function definitions on both devices. Most of the complicated parts of the macros stem from the fact that types of `void` are treated differently to other types in c. The other macros are just there to calculate the size of things like structs or arguments, and to expand function definitions from the RPC_FUNC() macro. Most of the stuff in these files is not critical to understand, as it has to do with the c compiler rather than actual function calls or robotics.

The other nice thing about the library is that the information sent over UART is minimal. Since both devices know the function definitions in advance, they don't have to spend things like transmitting the size or number of arguments over UART. This is good since the actual transmission step is by far the most time consuming part of this whole operation.

Finally, yes I know it's overengineered. It wouldn't be any fun if it wasnt :P