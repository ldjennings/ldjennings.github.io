#pragma once
#include <tinyrpc.h>
#include <shared-structs.h>

#ifdef TINYRPC_SERVER
    #include <hooks.h>
#endif

/* Return Type, Name, Input Params... */

RPC_LIST_START
    RPC_FUNC(void, setMotorEfforts, uint16_t, uint16_t)
    RPC_FUNC(void, setMotorTargetSpeeds, float, float)
    RPC_FUNC(void, setWheelTargetSpeeds, float, float)
    RPC_FUNC(DistanceReading, getSharpDistance, void)
    RPC_FUNC(DistanceReading, getHCSR04Distance, void)
    RPC_FUNC(IRFinderReading, getIRFinderReading, void)
    RPC_FUNC(Pose, getPoseEstimate, void)
    RPC_FUNC(CameraReading, getCameraReading, void)
    RPC_FUNC(void, resetPoseEstimate, void)
    RPC_FUNC(void, sendCode, uint8_t, uint8_t)
    RPC_FUNC(void, setPose, float, float)
RPC_LIST_END