#pragma once
#include <Arduino.h>

#ifdef __DEBUG__
    static const char* COMMA_TOKEN =   ", ";

    extern int __traceonce_id;

    void initDebug();
    void sendDebugPacket(const char* packetType, int ptLen, const char* payload, int pldLen);
    void sendPosePacket(const char* packetType, int ptLen, const char* payload, int pldLen);
    void __attribute__ ((noinline)) m_Debug(String header, String file, int line, String msg);
    void __attribute__ ((noinline)) m_TraceOnce(int tc, String header, String file, int line, String msg);

    #define DEBUG(x) m_Debug(" | [DEBUG] ", __FILE__, __LINE__, x);
    #define ERROR(x) m_Debug(" | [ERROR] ", __FILE__, __LINE__, x);
    #define TRACE(x) __traceonce_id = -1; m_Debug(" | [TRACE] ", __FILE__, __LINE__, x);

    // #define TRACE(x)

    #define TRACEONCE(x)                                                                                        \
        m_TraceOnce(__COUNTER__, " | [TRACE] ", __FILE__, __LINE__, x);                                         \

    // #define TRACEONCE(x)

    #define ASSERT(x, msg)                                                                                      \
        if((x) == 1) {                                                                                          \
            m_Debug(" | [ASSERT] ", __FILE__, __LINE__, msg);                                                   \
            while(1) {};                                                                                        \
        }

    #define SEND_SERIALIZED(topic, topicLen, payload, pldLen) \
        sendDebugPacket(topic, topicLen, payload, pldLen);

    #define UPDATE_DEBUG_POSE(payload, pldLen) \
        sendPosePacket("pose", 5, payload, pldLen);

#else

    #define DEBUG(x)
    #define ERROR(x)
    #define TRACE(x)
    #define TRACEONCE(x)
    #define ASSERT(x, msg)

#endif