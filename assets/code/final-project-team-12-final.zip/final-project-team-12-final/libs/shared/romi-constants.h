#pragma once

#define BASE_SPEED 25.0

#ifndef LIAM_ROMI
    #ifndef ARTHUR_ROMI
        #ifndef RILEY_ROMI
            #error Romi Constants File not defined - use one of LIAM_ROMI, ARTHUR_ROMI, or RILEY_ROMI
            #define WHEEL_TRACK
            #define WHEEL_DIAM
            #define TICKS_PER_ROT
            #define MOT_KP
            #define MOT_KI
            #define MOT_KD
        #endif
    #endif
#endif

#ifdef LIAM_ROMI
    #define WHEEL_TRACK 14.9
    #define WHEEL_DIAM 7.0
    #define TICKS_PER_ROT 1440
#endif

#ifdef ARTHUR_ROMI
    #define WHEEL_TRACK 14.9
    #define WHEEL_DIAM 7.0
    #define TICKS_PER_ROT 1440
    #define MOT_KP 3.0
    #define MOT_KI 2.0
    #define MOT_KD 2.0
    #define HEADING_KP 5.0
    #define LINEAR_KP 1.0
#endif

#ifdef RILEY_ROMI
    #define WHEEL_TRACK 14.1 //default = 14.9
    #define WHEEL_DIAM 6.95 // default = 7.0
    #define TICKS_PER_ROT 1440.0 //default = 1440
    #define MOT_KP 4
    #define MOT_KI 2
    #define MOT_KD 2
    #define PITCH_SENS .00875
    #define IMU_TIMESTEP 0.038
    #define HEADING_KP 1.0 // 5
    #define LINEAR_KP 0.25 // 1
#endif

#ifdef RAMP_ROMI
    #define WALL_FOLLOW_SIDE -1
    #define IR_ROLLING_AVG_WEIGHT 0.05
    #define RF_ROLLING_AVG_WEIGHT 0.35

    #define START_X CELL_LENGTH/2.0
    #define START_Y CELL_LENGTH/2.0
#endif

#ifdef IR_ROMI
    #define WALL_FOLLOW_SIDE 1
    #define IR_ROLLING_AVG_WEIGHT 0.50
    #define RF_ROLLING_AVG_WEIGHT 0.35

    #define START_X CELL_LENGTH/2.0
    #define START_Y CELL_LENGTH/2.0
#endif

#ifdef DOOR_ROMI
    #define WALL_FOLLOW_SIDE 1
    #define IR_ROLLING_AVG_WEIGHT 0.25
    #define RF_ROLLING_AVG_WEIGHT 0.80

    #define START_X CELL_LENGTH/3.0
    #define START_Y CELL_LENGTH/3.0
#endif

#if (!defined(RAMP_ROMI) && !defined(IR_ROMI) && !defined(DOOR_ROMI))
    #error Please define which romi this is!
#endif