#pragma once
#include <Arduino.h>

#define CELL_LENGTH 41.0f

struct DistanceReading {
    float value;
    bool valid;
} __attribute__((packed));

template <typename T>
struct Point {
    T x;
    T y;

    Point() {}
    Point(T x, T y) : x(x), y(y) {}

    Point(const Point& p) {
        x = p.x;
        y = p.y;
    }

    bool operator==(const Point& p) {
        return (p.x == this->x && p.y == this->y);
    }

} __attribute__((packed));

struct Pose {
    Point<float> pos;
    float angle;
    float pitch;
} __attribute__((packed));

struct IRFinderReading {
    Point<int16_t> points[4];
    bool valid;
} __attribute__((packed));

struct Tag {
    uint16_t header;
    uint16_t checksum;
    uint16_t id;
    Point<uint16_t> pos;
    Point<uint16_t> dim;
    uint16_t rot;
} __attribute__((packed));

struct CameraReading {
    bool foundReading;
    Tag info;
} __attribute__((packed));