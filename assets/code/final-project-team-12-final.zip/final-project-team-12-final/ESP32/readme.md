This is where the bulk of our code for the project is. The logic for our project was organized into `States`, which were essentially reusable snippets of logic. These `States` were then organized into `StateChains`, which were ordered lists of states that were executed in order. These `StateChains` were mutable, so it is possible to dynamically add or remove states as states are executing, which made it convienent for more complex logic. We also found it easier if the states themselves were "disposable", so each state is instantiated as a new class when it is added to a statechain, and deallocation is automatically handled when the `StateChain` expired (although i'm sure there's a memory leak somewhere in there). For example, the following:

```cpp
...
StateManager::newChain()
    .add(new State_Move(10.0))
    .add(new State_Turn(90.0))
    .add(new State_Move(20.0))
    .execute();
...
```

would be the code to move forward 10cm, turn 90 degrees, and move forward another 20cm.

Each State chass derives from a virtual `State` class, and implements a `begin()`, `loop()`, and `end()` function which are automatically called at the appropriate times by the `StateManager`.

In this repo, `src/state/State.cpp` contains the bulk of our actual robotic logic code. `src/state/StateManager.cpp` contains the implementation of the `State` and `Statechain` classes.

`debug.cpp` contains code for debug printing, as well as code to handle a websocket connection to a remote debug and mapping server. (`debug.h` is in the `libs/shared` folder, although it probably should be moved solely to the ESP-32.)

`mapping.cpp` deals with live updating the map and doing any pathfinding.