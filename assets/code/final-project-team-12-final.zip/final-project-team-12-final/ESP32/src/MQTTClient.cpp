#include <MQTTClient.h>
#include <Arduino.h>
#include <PubSubClient.h>
#include <mqtt.h>
#include <debug.h>
#include <globals.h>

String MQTTClient::IRCode;
String MQTTClient::DoorPosition;
bool   MQTTClient::IRButtonPressed;
bool   MQTTClient::RampRomiReady;
bool   MQTTClient::newDataAvailable[NUM_TOPICS];
bool MQTTClient::IR_Victory;
bool MQTTClient::Door_Victory;
bool   MQTTClient::irAlive;
bool   MQTTClient::rampAlive;
bool   MQTTClient::doorAlive;

MQTTClient::MQTTClient(void){} 

void MQTTClient::init(void){
    setup_mqtt();
    client.setCallback(callback);
    String topics = String("team") + String(teamNumber) + String("/#");
    while(!client.connected()) 
    {
        mqtt_reconnect();
    }   
    client.subscribe(topics.c_str());
}

void MQTTClient::update(){
    if(!client.loop()) {mqtt_reconnect();}
}

void MQTTClient::sendMessage(const String& topic, const String& message)
{
    publishMQTT(topic + String(':') + message);
}

/**
 * publishMQTT parses a message (received as "topic:message" over Serial) 
 * and appends the topic/message to the team number and sends it to an MQTT broker.
 * The MQTT packet will have the format
 * 
 *      "teamN/topic/message"
 * 
 * */
bool MQTTClient::publishMQTT(String& str)
{
    //Serial.println(str);

    int iCol = str.indexOf(':');
    if(iCol == -1) 
    {
        DEBUG("Failed to find delimiter");
        str = "";
        return false;
    }

    mqtt_reconnect(); // checks if connected and attempts to reconnect

    String topic = String("team") + String (teamNumber) + String('/') + str.substring(0, iCol);
    String message = str.substring(iCol + 1);

    bool success = client.publish(topic.c_str(), message.c_str());
    str = "";

    return success;
}



/**
 * callback() gets called whenever we receive a message for this team number 
 * (i.e., "teamN"). It strips off the team name and sends "topic:message"
 * over the UART.
 * */
void MQTTClient::callback(char* topic, byte *payload, unsigned int length) 
{
    //Serial.println("Callback called");
    String strTopic(topic);
    strTopic = strTopic.substring(strTopic.indexOf('/') + 1);
    String message = String(payload, length);

    if(strTopic.equalsIgnoreCase(TOPIC_IR_CODE)){
        IRCode = message;
        newDataAvailable[0] = true;
    }
    else if(strTopic.equalsIgnoreCase("Door_Robot")){
        doorAlive = true;
    }
    else if(strTopic.equalsIgnoreCase("Ramp_Robot")){
        rampAlive = true;
    }
    else if(strTopic.equalsIgnoreCase("IR_Robot")){
        irAlive = true;
    }
    else if(strTopic.equalsIgnoreCase(TOPIC_DOOR_POSITION)){
        DoorPosition = message;
        newDataAvailable[1] = true;
    }
    else if(strTopic.equalsIgnoreCase(TOPIC_BUTTON_PRESSED)){
        if(message.equalsIgnoreCase("true")){
            IRButtonPressed = true;
        }
        else{
            IRButtonPressed = false;
        }
        newDataAvailable[2] = true;
    }
    else if(strTopic.equalsIgnoreCase(TOPIC_RAMP_READY)) {
        if(message.equalsIgnoreCase("true")){
            RampRomiReady = true;
        }
        else{
            RampRomiReady = false;
        }
        newDataAvailable[3] = true;
    }
    else if(strTopic.equalsIgnoreCase(TOPIC_IR_VICTORY)) {
        IR_Victory = true;
        newDataAvailable[4] = true;
    }
    else if(strTopic.equalsIgnoreCase(TOPIC_DOOR_VICTORY)) {
        Door_Victory = true;
        newDataAvailable[5] = true;
    }
    else{
        DEBUG("Recieved MQTT that does not match any topic: " + strTopic + ':' + message );
    }

    
    
}