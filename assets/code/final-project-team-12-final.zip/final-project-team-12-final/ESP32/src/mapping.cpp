#include <mapping.h>
#include <globals.h>
#include <debug.h>

Point<int8_t> GlobalMapper::currentGridCell = Point<int8_t>(0, 0);
GlobalMapper::MapNode GlobalMapper::nodes[MAP_X][MAP_Y] = {};

Point<int8_t> GlobalMapper::calculateGridCellOfPos(Point<float> pos) {
    Point<int8_t> ret = {.x = (int8_t)constrain(pos.x / CELL_LENGTH, 0, MAP_X-1), .y = (int8_t)constrain(-pos.y / CELL_LENGTH, 0, MAP_Y-1)};
    return ret;
}

Point<float> GlobalMapper::gridPointToGlobalPoint(Point<int8_t> gridPoint) {
    Point<float> ret = {.x = gridPoint.x * CELL_LENGTH + CELL_LENGTH/2, .y = gridPoint.y * CELL_LENGTH + CELL_LENGTH/2};
    return ret;
}

void GlobalMapper::updateGlobalMapPosition() {
    auto gridCell = calculateGridCellOfPos(g_robot.pose.pos);
    
    if(gridCell.x == currentGridCell.x && gridCell.y == currentGridCell.y) {
        return; // we don't need to update the grid cell since there have been no changes since last update
    }

    // set the new node to be traversable
    nodes[gridCell.x][gridCell.y].information &= ~UNKNOWN;
    nodes[gridCell.x][gridCell.y].information |= PASSABLE;

    // we are in a different node than we were last time

    // mark the last node as connected in the direction we left from
    nodes[currentGridCell.x][currentGridCell.y].information |= (
        ((gridCell.x - currentGridCell.x > 0) << 0)    |               
        ((gridCell.x - currentGridCell.x < 0) << 1)    |               
        ((gridCell.y - currentGridCell.y > 0) << 2)    |               
        ((gridCell.y - currentGridCell.y < 0) << 3)      );

    // mark the node we just entered as connected in the direction we entered from
    nodes[gridCell.x][gridCell.y].information       |= (
        ((gridCell.x - currentGridCell.x > 0) << 1) |               
        ((gridCell.x - currentGridCell.x < 0) << 0) |               
        ((gridCell.y - currentGridCell.y > 0) << 3) |               
        ((gridCell.y - currentGridCell.y < 0) << 2)  );


    // set the current node to where we are now
    currentGridCell.x = gridCell.x;
    currentGridCell.y = gridCell.y;

    SEND_SERIALIZED("globalMap", 10, (const char*)nodes, sizeof(nodes))
}

GlobalMapper::Waypoint* GlobalMapper::navigateToGridCell(Point<int8_t> tgt) {

    bool visited[MAP_X][MAP_Y];

    for(int x = 0; x < MAP_X; x++) {
        for(int y = 0; y < MAP_Y; y++) {
            visited[x][y] = false;
        }
    }

    visited[currentGridCell.x][currentGridCell.y] = true;


    Point<int8_t> stack[MAP_X * MAP_Y];
    stack[0] = currentGridCell;

    int stack_idx = 0;

    while(stack_idx != -1) {
        auto p = stack[stack_idx];
        auto n = &nodes[p.x][p.y];

        visited[p.x][p.y] = true;

        /* check if we found the destination */
        if(p == tgt) {
            Waypoint* wp = (Waypoint*)malloc(sizeof(Waypoint));
            Waypoint* ret = wp;

            for(int i = 0; i <= stack_idx; i++) {
                wp->position = gridPointToGlobalPoint(stack[i]);
                if(i < stack_idx) {
                    wp->next = (Waypoint*)malloc(sizeof(Waypoint));
                    wp = wp->next;
                }
            }

            wp->next = nullptr;
            return ret;
        }

        /* move in one of the four directions */

        if((n->information & XPLUS) && p.x < MAP_X - 1 && !visited[p.x + 1][p.y]) {
            stack_idx++;
            stack[stack_idx] = Point<int8_t>(p.x + 1, p.y);
            continue;
        }

        if((n->information & XMINUS) && p.x > 0 && !visited[p.x - 1][p.y]) {
            stack_idx++;
            stack[stack_idx] = Point<int8_t>(p.x - 1, p.y);
            continue;
        }

        if((n->information & YPLUS) && p.y < MAP_Y - 1 && !visited[p.x][p.y + 1]) {
            stack_idx++;
            stack[stack_idx] = Point<int8_t>(p.x, p.y + 1);
            continue;
        }

        if((n->information & YMINUS) && p.y > 0 && !visited[p.x][p.y - 1]) {
            stack_idx++;
            stack[stack_idx] = Point<int8_t>(p.x, p.y - 1);
            continue;
        }

        /* if we get here, this node is completely disconnected. pop it */
        stack_idx--;
    }

    /* we couldn't find a path :( */
    return nullptr;
}

Point<int8_t> GlobalMapper::getForwardCell() {
    Point<int8_t> ret = currentGridCell;
    ret.x += (roundf(0.70710678118 * cosf(g_robot.pose.angle)));
    ret.y += -(roundf(0.70710678118 * sinf(g_robot.pose.angle)));
    return ret;
}

Point<int8_t> GlobalMapper::getCurrentCell() {
    return currentGridCell;
}

void GlobalMapper::init() {
    auto startingCell = calculateGridCellOfPos(g_robot.pose.pos);
    nodes[startingCell.x][startingCell.y].information &= ~UNKNOWN;
    nodes[startingCell.x][startingCell.y].information |= PASSABLE;

    /* TESTING CODE */
    nodes[0][2].information |= PASSABLE;
    nodes[0][2].information |= PASSABLE;

    nodes[0][2].information &= ~UNKNOWN;
    nodes[0][2].information &= ~UNKNOWN;
}

bool GlobalMapper::wholeMapExplored() {
    bool explored = PASSABLE;

    for(int i = 0; i < MAP_X; i++) {
        for(int j = 0; j < MAP_Y; j++) {
            explored &= nodes[i][j].information & PASSABLE;
        }
    } 

    return explored == PASSABLE;
}