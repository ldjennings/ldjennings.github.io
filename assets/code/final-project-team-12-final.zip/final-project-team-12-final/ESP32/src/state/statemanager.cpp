#include "state.h"
#include "debug.h"

/* State Manager */

StateManager::StateChain* StateManager::currentStateChain = nullptr;
StateManager::StateChain* StateManager::idleStateChain = nullptr;
uint8_t StateManager::activeStateType = -1;
StateManager::StateKeyMap StateManager::mappings[N_STATES + 1] = {};

void StateManager::mapKeyPress(uint8_t key, void (*cb)(), States inState) {
    DEBUG("Mapping Key Press for key " + String(key) + " in state " + String(inState))
    ASSERT(mappings[inState].idx >= MAX_BUTTONS_PER_STATE, "Too many buttons per state! increase MAX_BUTTONS_PER_STATE")
    mappings[inState].map[mappings[inState].idx++] = {.button = key, .cb = cb};
}

void StateManager::loop() {
    currentStateChain->loop();
}

void StateManager::keyLoop() {
    int16_t press = decoder.getKeyCode();

    if(press != -1) {
        DEBUG("Press: " + String(press));
        DEBUG("Active State ID: " + String(activeStateType))
        /* First, Check for specific state callbacks */
        for(int i = 0; i < MAX_BUTTONS_PER_STATE; i++) {
            if(mappings[activeStateType].map[i].button == press) {
                DEBUG("Calling Button Callback... (Specific State)")
                mappings[activeStateType].map[i].cb();
                return;
            }
        }

        /* Then, check for callbacks that would be done in any state */
        for(int i = 0; i < MAX_BUTTONS_PER_STATE; i++) {
            if(mappings[STATE_ANY].map[i].button == press) {
                DEBUG("Calling Button Callback... (Any State)")
                mappings[STATE_ANY].map[i].cb();
                return;
            }
        }
    }
}

void StateManager::setDefaultStateChain(StateChain* s) {
    idleStateChain = s;

    ASSERT(idleStateChain == nullptr, "Attempting to assign empty SC")
    ASSERT(idleStateChain->current == nullptr, "Attempting to assign empty statechain!")
    activeStateType = idleStateChain->current->stateType;
    resumeIdle();
}

StateManager::StateChain& StateManager::newChain() {
    auto ret = new StateManager::StateChain();
    return *ret;
}

void StateManager::execute(StateChain& sc) {
    ASSERT(sc.length == 0, "Attempting to execute statechain of length 0!")
    ASSERT(sc.current == nullptr, "Attempting to execute null StateChain!")

    activeStateType = sc.current->stateType;
    currentStateChain = &sc;
    currentStateChain->current->begin();
}

StateManager::StateChain& StateManager::getActiveStateChain() {
    return *currentStateChain;
}

void StateManager::StateChain::moveToNextState() {
    current->end();
    if(current->next != nullptr) {
        current = current->next;
        current->begin();
    } else {
        delete this;
        resumeIdle();
    }
}

StateManager::StateChain::~StateChain()  {
    DEBUG("Destroyed Statechain.")

    while(first->next != nullptr) {
        delete first;
        first = first->next;
    }
}

StateManager::StateChain& StateManager::StateChain::add(State* s) {
    if(length == 0) {
        // This is our first state
        first = s;
        current = s;
        last = s;
    } else {
        last->next = s;
        last = last->next;
    }
    length++;
    return *this;
}

StateManager::StateChain& StateManager::StateChain::push(State* s) {
    s->next = current->next;
    current->next = s;

    length++;

    return(*this);
}

void StateManager::StateChain::loop() {
    ASSERT(current == nullptr, "Attempting to execute null state!")
    if(current->loop()) {
        moveToNextState();
    }
}

void StateManager::StateChain::execute() {
    DEBUG("Executing new statechain")
    StateManager::execute(*this);
}