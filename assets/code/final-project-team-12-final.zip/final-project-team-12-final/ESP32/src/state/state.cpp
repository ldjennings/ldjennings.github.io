#include <state.h>
#include <globals.h>
#include <debug.h>
#include <shared-functions.h>
#include <romi-constants.h>
#include <mapping.h>

/* Helper Functions */

float lastHRDist = 20, HRdelta = 20.0;
float distance = 0;
float sum = 0, lastDiff = 0;

bool checkApproachEvent(float targetDistance)
{
    // If the sensor has recorded a new value, update the stored boolean to check if too 0 close
    // to the wall
    if (g_robot.irRollingAverage.value > 50 || g_robot.irRollingAverage.value < 0)
        return false;
    return (g_robot.irRollingAverage.value < targetDistance);

    return false;
}

/* Main method for following the wall, method takes in 3 parameters, a distance in cm, a speed in cm/sec, and a proportionality constant */

void handleWallFollow(float wallDistance, float baseSpeed, float kp = WALL_KP)
{
    auto dist = g_robot.rfRollingAverage;

    dist.value = constrain(dist.value, 0, CELL_LENGTH*1.25);

    float diff = dist.value - wallDistance;

    sum += diff;
    float delta = diff - lastDiff;
    lastDiff = diff;

    float offset = diff * kp + delta * WALL_KD + sum * WALL_KI;

    RPC::setMotorTargetSpeeds(baseSpeed - offset * WALL_FOLLOW_SIDE, baseSpeed + offset * WALL_FOLLOW_SIDE);
}
/*
    Handles moving to a point in a cell adjacent to our current cell;
    Returns True if at point, false otherwise.
*/
bool handleMoveToAdjecentCell(Point<int8_t> cell, float delta, float wallDistance = WALL_DISTANCE, float baseSpeed = BASE_SPEED) {
    auto pt = GlobalMapper::gridPointToGlobalPoint(cell);

    SEND_SERIALIZED("targetPoint", 12, (const char*)&pt, sizeof(pt));

    if(sqrtf(pow(g_robot.pose.pos.x - pt.x, 2 + pow(g_robot.pose.pos.y - pt.y, 2))) < delta) { // We've arrived.
        return true;
    }

    if(g_robot.rfDistance.value < CELL_LENGTH) { // We are near a wall - we should use it to wall follow to the next point
        handleWallFollow(wallDistance, baseSpeed);
        return false;
    }

    // We aren't near a guide wall - we have to rely on dead reckoning.

    float cX = g_robot.pose.pos.x;
    float cY = g_robot.pose.pos.y;
    float cT = g_robot.pose.angle;

    float dX = cX - pt.x;
    float dY = cY + pt.y;

    // Rotation matrix calculation.

    float tX = -dY * cosf(cT) + dX * sinf(cT);
    float tY = -dY * sinf(cT) - dX * cosf(cT);

    // Now that tX and tY are wrt local ref. frame, we can easily find the angle difference.

    float angleDiff =  atan2f(tX, tY);

    // Calculate linear distance for forward motor speed prop. control.

    float euclidDist = sqrtf(powf(dX, 2) + powf(dY, 2));

    // Constrain speeds so we don't go super fast and miss encoder counts or something
    float speed = constrain(euclidDist * LINEAR_KP, -baseSpeed, baseSpeed);
    float angSpeed = constrain((angleDiff * HEADING_KP), -5.0, 5.0);

    // Just add the linear speed and angular speed together
    RPC::setWheelTargetSpeeds(speed - angSpeed, speed + angSpeed);

    return false;
}

/* Idle State */
void State_Idle::begin() {
    TRACE("State_Idle::begin")
}

bool State_Idle::loop() {
    TRACEONCE("State_Idle::loop")
    //testing code for the MQTT BROKER
    static uint32_t lastSend = 0;
    uint32_t currTime = millis();
    if (currTime - lastSend >= 3000) // send every three seconds
    {
        lastSend = currTime;
        DEBUG("Idle Alive.")
        // sendMessage("time", String(currTime));
    }
    return false;
}

void State_Idle::end() {
    TRACE("State_Idle::end")
}

/* ESTOP State */
void State_Estop::begin() {
    TRACE("State_Estop::Begin")
    RPC::setMotorEfforts(0, 0);
}

bool State_Estop::loop() {
    TRACEONCE("State_Estop::loop")
    RPC::setMotorEfforts(0, 0);
    return false;
}

void State_Estop::resumeExecution() {
    DEBUG("Resuming execution...");
    StateManager::execute(savedChain);
}

void State_Estop::end() {
    TRACEONCE("State_Estop::end")
}

/*  Turning State 
    This state handles turning in place for a given input angle */
void State_Turn::begin() {
    TRACE("State_Turn::begin")

    wheelSpeed = ((angularSpeed/360.0) * (PI * WHEEL_TRACK));

    timer.cancel();
}

bool State_Turn::loop() {
    TRACEONCE("State_Turn::loop")

    if (timer.checkExpired())
    {   
        RPC::setMotorEfforts(0, 0);
        return true;
    }

    if (!timer.IsRunning())
    {
        
        if(angle < 0) {
            angle = -angle;
            wheelSpeed = -wheelSpeed;
        }
        /* need to calculate the time based on the angle and wheelspeeds*/
        float time = angle/angularSpeed;

        RPC::setWheelTargetSpeeds(wheelSpeed, -wheelSpeed);
        timer.Start(time * 1000.0);
    }

    return false;
}

void State_Turn::end() {
    TRACE("State_Turn::end")
}

/*  Move to Point State
    Takes in a target point (x,y) and an optional "delta" to set how lenient we are with determining if we have arrived at the set point */

void State_MoveToPoint::begin() {
    TRACE("State_MoveToPoint::begin")

    //this macro sends the current target point to the Webapp in a json payload
    SEND_SERIALIZED("targetPoint", 12, (const char*)&tgt, sizeof(tgt));
}

bool State_MoveToPoint::loop() {
    TRACEONCE("State_MoveToPoint::loop")

    /* Calculates the Euclidean distance between our current pose and the target pose and compares that distance to our delta*/
    if(sqrtf(pow(g_robot.pose.pos.x - tgt.x, 2 + pow(g_robot.pose.pos.y - tgt.y, 2))) < delta) { // We've arrived.
        return true;
    }

    float cX = g_robot.pose.pos.x;
    float cY = g_robot.pose.pos.y;
    float cT = g_robot.pose.angle;

    float dX = cX - tgt.x;
    float dY = cY + tgt.y;

    // Rotation matrix calculation.

    float tX = -dY * cosf(cT) + dX * sinf(cT);
    float tY = -dY * sinf(cT) - dX * cosf(cT);

    // Now that tX and tY are wrt local ref. frame, we can easily find the angle difference.

    float angleDiff =  atan2f(tX, tY);

    // Calculate linear distance for forward motor speed prop. control.

    float euclidDist = sqrtf(powf(dX, 2) + powf(dY, 2));

    // Constrain speeds so we don't go super fast and miss encoder counts or something
    float speed = constrain(euclidDist * LINEAR_KP, -10.0, 10.0);
    float angSpeed = constrain((angleDiff * HEADING_KP), -5.0, 5.0);

    // Just add the linear speed and angular speed together
    RPC::setWheelTargetSpeeds(speed - angSpeed, speed + angSpeed);

    return false;
}

void State_MoveToPoint::end() {
    TRACE("State_MoveToPoint::end")
}

/* Explore State */

/* This state handles exploring the entire maze by left wall following */

void State_Explore::begin() {
    TRACE("State_Explore::begin")

    DEBUG("Entered the explore state.")
}

bool State_Explore::loop() {
    TRACEONCE("State_Explore::loop")

    // DEBUG("Distance: " + String(g_robot.rfRollingAverage.value))

    DEBUG("rf " + String(g_robot.rfRollingAverage.value) + " | ir " + String(g_robot.irRollingAverage.value))
    // DEBUG("ir " + String(g_robot.rfRollingAverage.value))
    Pose curPose = g_robot.pose;

    if(checkApproachEvent(18.5)) {
        DEBUG("Saw Approach Event.")

        if(g_robot.rfRollingAverage.value > CELL_LENGTH) {
            StateManager::newChain()
                .add(new State_Turn(-90.0))
                .add(new State_MoveAhead(CELL_LENGTH))
                .add(new State_Explore())
                .execute();
        } else {
            StateManager::newChain()
                .add(new State_Turn(90.0))
                .add(new State_Explore())
                .execute();
        }

    } else {
        handleWallFollow(CELL_LENGTH/2.0, BASE_SPEED-2,0.48);
    }
    return false;
}

void State_Explore::end() {
    TRACE("State_Explore::end")
}

/* Move Forward State 
    This State handles moving forward a given distance for a calculated amount of time*/

void State_MoveAhead::begin() {
    TRACE("State_MoveAhead::begin")
}

bool State_MoveAhead::loop() {
    TRACEONCE("State_MoveAhead::loop")

    if(!timer.IsRunning()) {
        if(distance < 0) {
            distance = -distance;
            speed = -speed;
        }
        float time = distance/abs(speed);
        RPC::setWheelTargetSpeeds(speed, speed);
        timer.start(time * 1000.0);
    }

    if(timer.checkExpired()) {
        RPC::setMotorEfforts(0, 0);
        return true;
    }

    return false;
}

void State_MoveAhead::end() {
    TRACE("State_MoveAhead::end")
}

/*  IR Follow State 
    This state handles left wall following until the IR beacon is seen.
    At which point, we take the positional data from the IRFinder and utilze a proportional control algorithm to center the robot and drive towards the beacon */

void State_IR_Follow::begin() {
    DEBUG("entered IR following state");

    hasSeen = g_robot.beaconPose.valid;
}

 /* helper method using proportional control to align the robot with the IR beacon*/

void State_IR_Follow::handleIRFollow(IRFinderReading irData) {

    /* if new data has been seen we attempt to update the control loop*/
    if(irData.valid) {
        DEBUG("Valid data found");
        currPoint = irData.points[0];
        printf("valid: %d, x: %d, y: %d \n", irData.valid, irData.points[0].x, irData.points[0].x);
        
        /* only if the data from the sensor is a good reading, we update the wheel speeds*/
        if(currPoint.y != 1023) {
            /* the difference between the IR's x position and the middle of the frame determines how much we need to turn to face the IR beacon head on. */
            Xerror = currPoint.x - IR_MIDDLE;

            /* We update the current speeds of the motor depeding on the error */
            RPC::setWheelTargetSpeeds( (BASE_SPEED - 12) - Xerror*IR_KP, (BASE_SPEED - 12) + Xerror*IR_KP); 
        }
        else {
            RPC::setWheelTargetSpeeds((BASE_SPEED - 12), (BASE_SPEED - 12)); 
        }
    }
}

/*  This method sends the current position and rotation of the IR_Robot to the MQTT at the time of the Button being pushed (AKA the Door code) 
    We figure the code via the pose data and the knowledge of a cells size  */
void State_IR_Follow::SendCurrentPositionToMQTT() {
    /* asks */
   
    /* A cell's size is 40 cm, so the 100's and 10's digit is the current positions divided by 40 round to the nearest int
       The current angle of the robot determines the 1's digit and that can be found by the angle divided by 90 rounded to the nearest int */
    
    u_int8_t c1 = (u_int8_t) roundf( ( abs(g_robot.pose.pos.y) - 20.0) / 40.0);
    u_int8_t c2 = (u_int8_t) roundf( ( abs(g_robot.pose.pos.x) - 20.0) / 40.0);
    u_int8_t c3 = (u_int8_t) roundf( (abs(g_robot.pose.angle) * 180.0 / PI) / 90.0);

    //DEBUG("CurPose: " +  String(g_robot.pose.pos.x) + ", " + String(g_robot.pose.pos.y) + ", "+ String(g_robot.pose.angle));
    //DEBUG("Cur Code: " +  String(c1) + ", " + String(c2) + ", " + String(c3));
    u_int8_t code = 100 * c1 + 10 * c2 + 1 * c3; 
    
    /* We send both the code to the MQTT as well as a message to the Ramp Romi to begin tag state */
     mqtt.sendMessage(TOPIC_IR_CODE, String(code));
     mqtt.sendMessage(TOPIC_BUTTON_PRESSED, "true");
}

bool State_IR_Follow::loop() {

    hasSeen |= g_robot.beaconPose.valid;

    if(hasSeen) {

        /*  if we are within reasonable distance to the IR Beacon, we dead reckon towards button then idle
        We use the motion state to move towards the button */
        if(checkApproachEvent(STOP_DISTANCE)) {
            RPC::setWheelTargetSpeeds(0,0);

            float dist = constrain(g_robot.irDistance.value, 5.0, 15.0);
            
            /* We use this method to send the IR_Robots current position and rotation to the MQTT as this is the code to open the Door */
            SendCurrentPositionToMQTT();

            StateManager::getActiveStateChain()
                .add(new State_MoveAhead(dist,3.0))
                .add(new State_MoveAhead(-dist, 3.0))
                .add(new State_Wait_For_MQTT());
            return true;
        }
        else {
            handleIRFollow(g_robot.beaconPose);
            return false;
        }
    }

    /* if we see a wall without having seen the IR beacon, we turn right and continue to wall follow */
    if(checkApproachEvent(STOP_DISTANCE - 2)) {
        
        DEBUG("Turning Right");
        StateManager::getActiveStateChain()
            .add(new State_Turn(90))
            .add(new State_IR_Follow());
        return true;
    }
    handleWallFollow(CELL_LENGTH/3.5, BASE_SPEED); 
    return false;
}

void State_IR_Follow::end() {
    TRACE("State_IR_Follow::end")
}

/* Ramp Follow State
    This state handles right wall following until the robot detects a change in pitch */

void State_Ramp_Wall_Follow::begin(){
    TRACE("State_Ramp_Wall_Follow::Begin")
}

bool State_Ramp_Wall_Follow::loop(){
    /* if we know that we are on the ramp, then we move to the next cell until our pitch levels out*/
    if(isClimbing){
        handleMoveToAdjecentCell(GlobalMapper::getForwardCell(), 10.0, WALL_DISTANCE_RAMP, rampSpeed);
        /* Software hysteresis to ensure that we dont immediately exit this state after detecting an upward spike in pitch */
        return g_robot.pose.pitch < rampAngle-degreeEpsilon;
    }
    else{
        /* check to see if we have began climbing up the ramp with built in Software hysteresis */
        isClimbing = g_robot.pose.pitch > rampAngle + degreeEpsilon;
        //DEBUG("Current Angle : " + String(g_robot.pose.pitch))

        /* if we have gone too far, we know that the ramp is not currently ahead of us, so we will turn around and check the next column for the ramp */
        if(g_robot.pose.pos.x > xlimit){
            StateManager::newChain()
                .add(new State_Turn(180.0))
                .add(new State_Ramp_Wall_Follow())
                .add(new State_Capture_Tag())
                .execute();
        }
        /* if we run into a wall, we turn left and continue to wall follolw*/
        else if(checkApproachEvent(STOP_DISTANCE)){
            StateManager::newChain()
                .add(new State_Turn(-90.0))
                .add(new State_Ramp_Wall_Follow())
                .add(new State_Capture_Tag())
                .execute();
        }
        handleWallFollow(WALL_DISTANCE, BASE_SPEED - 10);
    }
    return false;
}

void State_Ramp_Wall_Follow::end(){
    TRACE("State_Ramp_Wall_Follow::End")
    RPC::setMotorTargetSpeeds(0,0);
}

/*  AprilTag Capture State
    This state waits until an apriltag is seen and uploads it to the MQTT */

void State_Capture_Tag::begin(){
    TRACE("State_Ramp_Wall_Follow::Begin")
    mqtt.sendMessage(TOPIC_RAMP_READY, "true");
}

void State_Capture_Tag::end(){
    TRACE("State_Ramp_Wall_Follow::End")
}

bool State_Capture_Tag::loop(){
    CameraReading reading = RPC::getCameraReading().await();
    if(reading.foundReading){
        // send a bunch of messages

        if(reading.info.id == 0) {
            StateManager::newChain().add(new State_Capture_Tag()).execute();
            return true;
        }
        
        String doorPos = String(reading.info.id) + String((int) roundf(reading.info.rot/90.0) % 4); 
        DEBUG("found tag: " + doorPos);
        mqtt.sendMessage(TOPIC_DOOR_POSITION, doorPos);

        int8_t doory = doorPos.substring(0,1).toInt();
        int8_t doorx = doorPos.substring(1,2).toInt();

        StateManager::getActiveStateChain()
            .add(new State_Turn(180))
            .add(new State_Leave_Ramp(GlobalMapper::gridPointToGlobalPoint(Point<int8_t>(doorx, doory))));
        return true;
    }
    return false;
}

/*  Turn to Face State
    Handles turning to a given angle using inverse kinematics (non naive turning)*/

void State_Turn_To_Face::begin() {
    TRACE("State_Turn_To_Face::begin")
}

bool State_Turn_To_Face::loop() {
    TRACEONCE("State_Turn_To_Face::loop")

    float cX = g_robot.pose.pos.x;
    float cY = g_robot.pose.pos.y;
    float cT = g_robot.pose.angle;

    float dX = cX - tgt.x;
    float dY = cY + tgt.y;

    // Rotation matrix calculation.

    float tX = -dY * cosf(cT) + dX * sinf(cT);
    float tY = -dY * sinf(cT) - dX * cosf(cT);

    // Now that tX and tY are wrt local ref. frame, we can easily find the angle difference.

    float angleDiff =  atan2f(tX, tY);

    StateManager::getActiveStateChain()
        .push(new State_Turn((angleDiff / PI) * -180.0));
    return true;
}

void State_Turn_To_Face::end() {
    TRACE("State_Turn_To_Face::end")

    RPC::setWheelTargetSpeeds(0, 0);
}

void State_Follow_Waypoints::begin() {
    TRACE("State_Follow_Waypoints::begin")
}

bool State_Follow_Waypoints::loop() {
    TRACE("State_Follow_Waypoints::loop")

    if(waypoints != nullptr && waypoints->next != nullptr) {
        float cX = g_robot.pose.pos.x;
        float cY = g_robot.pose.pos.y;
        float cT = g_robot.pose.angle;

        float dX = cX - waypoints->next->position.x;
        float dY = cY + waypoints->next->position.y;

        // Rotation matrix calculation.

        float tX = -dY * cosf(cT) + dX * sinf(cT);
        float tY = -dY * sinf(cT) - dX * cosf(cT);

        // Now that tX and tY are wrt local ref. frame, we can easily find the angle difference.

        float angleDiff =  atan2f(tX, tY);

        StateManager::getActiveStateChain()
            .push(new State_Follow_Waypoints(waypoints->next))
            .push(new State_MoveAhead(sqrtf(dX*dX + dY*dY)))
            .push(new State_Turn((angleDiff / PI) * -180.0));
        return true;
    } else {
        DEBUG("Done / Couldn't Find a Path!")
    }
    return true;
}

void State_Follow_Waypoints::end() {
    TRACE("State_Follow_Waypoints::end")
}

void State_MoveAdj::begin() {
    TRACE("State_MoveAdj::begin")
}

bool State_MoveAdj::loop() {
    TRACEONCE("State_MoveAdj::loop")

    return handleMoveToAdjecentCell(GlobalMapper::getForwardCell(), 3.0);
}

void State_MoveAdj::end() {
    TRACE("State_MoveAdj::end")
}

/* We can assume that we are in the victory cell at this time, so we only need to turn to the door, send code and enter*/

void State_Outside_Door::begin() {
    TRACE("State_Outside_Door::begin")

       float curAngle = g_robot.pose.angle * 180.0/PI;
       angleDiff = curAngle-victoryAngle; //will be negative when we need to turn RIGHT, and positive when we need to turn left
       if(abs(angleDiff) > 10) {
        StateManager::getActiveStateChain()
                .add(new State_Turn(angleDiff))
                .add(new State_Outside_Door(victoryAngle));
       }
       
}

bool State_Outside_Door::loop() {

    if(abs(angleDiff) > 10) {
        return true;
    }

    if(waitingForOpen) {
        bool open = g_robot.irRollingAverage.value > 25.0;
        DEBUG("waiting");

        if(open) {
            mqtt.sendMessage("victory", "royal");
            StateManager::getActiveStateChain()
                .add(new State_MoveAhead(CELL_LENGTH+7))
                .add(new State_Idle());
            return true;
        }
    } else {
        if(mqtt.IRCodeAvailable()) {
            int code = mqtt.getIRCode().toInt(); //"122"
            DEBUG("Code: " + String(code));
            uint8_t c1 = code % 10; // gets the 1's digit; 
            code /= 10; //"12"
            uint8_t c2 = code % 10; // gets the 10's digit;
            code /= 10; // "1"
            uint8_t c3 = code; // gets the 100's digit;
            uint8_t reset = 99;

            DEBUG(" -> " + String(c3) + ", " + String(c2) + ", " + String(c1));
            RPC::sendCode(0x00, reset);
            delay(100);
            RPC::sendCode(0x00, c3);
            delay(100);
            RPC::sendCode(0x00, c2);
            delay(100);
            RPC::sendCode(0x00, c1);
            waitingForOpen = true;
        }
    }
    return false;
}

void State_Outside_Door::end() {
    TRACE("State_Outside_Door::end!!")
}

void State_Navigate_To_Door::begin() {
    TRACE("State_Navigate_To_Door::begin")
}

bool State_Navigate_To_Door::loop() {
    TRACE("State_Navigate_To_Door::loop")

    if(g_robot.pose.pos.x - 1.0 < GlobalMapper::gridPointToGlobalPoint(frontOfDoorCell).x) {
        handleWallFollow(CELL_LENGTH/2.0, BASE_SPEED);
        return false;
    }
    else {
        shouldTurn = true;
    }

    if(shouldTurn) {

        float angle = mqtt.getDoorPosition().substring(2).toInt() * 90.0;
        // DEBUG(String(angle))
        StateManager::getActiveStateChain()
            .add(new State_Turn_To_Face(GlobalMapper::gridPointToGlobalPoint(frontOfDoorCell)))
            .add(new State_MoveAhead(abs(GlobalMapper::gridPointToGlobalPoint(frontOfDoorCell).y+10 + g_robot.pose.pos.y)))
            .add(new State_Outside_Door(angle));
        return true;
    }

    return false;
}

void State_Navigate_To_Door::end() {
    TRACE("State_Navigate_To_Door::end")
}


void State_Wait_For_MQTT::begin() {
    TRACE("statte::begin")

    
    #ifdef DOOR_ROMI
        mqtt.sendMessage("Door_Robot", "Online");
    #endif
    #ifdef IR_ROMI
        mqtt.sendMessage("IR_Robot", "Online");
    #endif
    #ifdef RAMP_ROMI
        mqtt.sendMessage("Ramp_Robot", "Online");
    #endif
}

bool State_Wait_For_MQTT::loop() {
    TRACEONCE("statte::begin")
    //if(mqtt.isAllConnected()) {
    #ifdef DOOR_ROMI
        if(mqtt.doorPositionAvailible() && mqtt.IRCodeAvailable()) {

        Point<int8_t> vp;
        vp.y = mqtt.getDoorPosition().substring(0,1).toInt();
        vp.x = mqtt.getDoorPosition().substring(1,2).toInt();

        DEBUG(String(vp.x))
        DEBUG(String(vp.y))

        StateManager::getActiveStateChain().add(new State_Navigate_To_Door(vp));
        return true;
    }
    
    #endif
    

    #ifdef IR_ROMI
        if(mqtt.isIRRomiDone()) {
            StateManager::newChain().add(new State_Explore()).execute();
            return false;
        }
        //  StateManager::newChain().add(new State_Idle()).execute();
        return false;
    #endif
    return false;
    // }
    // else {
    //     return mqtt.isAllConnected();
    // }
   // }
    return false;
}

void State_Wait_For_MQTT::end() {
    TRACE("State_Navigate_To_Door::begin")
}

void State_Leave_Ramp::begin() {

}

bool State_Leave_Ramp::loop() {
    if(g_robot.pose.pos.x < CELL_LENGTH)
        primed = true;

    if(primed && g_robot.pose.pos.x >= targetCell.x) {
        RPC::setMotorEfforts(0, 0);

        float angle = mqtt.getDoorPosition().substring(2).toInt() * 90.0;

        StateManager::getActiveStateChain()
            .add(new State_MoveAhead(abs(targetCell.y + g_robot.pose.pos.y)))
            .add(new State_Outside_Door(angle));
        return true;
    }

    if(checkApproachEvent(STOP_DISTANCE) && g_robot.pose.pitch > -3.0) {
        StateManager::getActiveStateChain()
            .add(new State_Turn(-90.0))
            .add(new State_Leave_Ramp(targetCell));

        return true;
    } else {
        handleWallFollow(15.0, BASE_SPEED, 0.25);   
    }
    return false;
}

void State_Leave_Ramp::end() {

}