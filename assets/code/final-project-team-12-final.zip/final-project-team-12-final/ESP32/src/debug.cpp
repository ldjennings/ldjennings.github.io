#include <debug.h>
#include <WebSocketsClient.h>
#include <debug.h>
#include <shared-functions.h>
#include <base64.h>


int __traceonce_id = -1;
WebSocketsClient ws_client;
QueueHandle_t poseQueue;
QueueHandle_t debugQueue;

struct DebugMessage {
	void* field;
	int fieldLen;
	void* payload;
	int pldLen;
};

void sendPosePacket(const char* packetType, int ptLen, const char* payload, int pldLen) {
	DebugMessage msg = {.field = malloc(ptLen), .fieldLen = ptLen, .payload = malloc(pldLen), .pldLen = pldLen};
	memcpy(msg.field, packetType, ptLen);
	memcpy(msg.payload, payload, pldLen);

	if(xQueueSendToFront(poseQueue, &msg, 0) != pdTRUE) {
		free(msg.payload);
		free(msg.field);
	}
}

/* pass a debug packet to the debug thread. since ownership and pointer lifetime is very well defined in this case, we can just use malloc */
void sendDebugPacket(const char* packetType, int ptLen, const char* payload, int pldLen) {
	DebugMessage msg = {.field = malloc(ptLen), .fieldLen = ptLen, .payload = malloc(pldLen), .pldLen = pldLen};
	memcpy(msg.field, packetType, ptLen);
	memcpy(msg.payload, payload, pldLen);

	if(xQueueSend(debugQueue, &msg, 0) != pdTRUE) {
		free(msg.payload);
		free(msg.field);
	}
}

void m_Debug(String header, String file, int line, String msg) {
	char buf[300];
	char fileline[100];
    snprintf(fileline, 99, "%s, %d", file.c_str(), line);
    int n = snprintf(buf, 299, "%-50s %s %s\n", fileline, header.c_str(), msg.c_str());

	auto debugTopic = "loggingMessage";
	sendDebugPacket(debugTopic, 15, buf, n);

    Serial.print(buf);
}

void m_TraceOnce(int tc, String header, String file, int line, String msg) {
    if(tc != __traceonce_id) {
        __traceonce_id = tc;
        m_Debug(" | [TRACE] ", file, line, msg); 
    }
}
void webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {

	switch(type) {
		case WStype_DISCONNECTED:
			break;
		case WStype_CONNECTED:
			ws_client.sendTXT("{\"connection\":true}");
			break;
		case WStype_TEXT:
			// send message to server
			// webSocket.sendTXT("message here");
			break;
		case WStype_BIN:
		case WStype_ERROR:			
		case WStype_FRAGMENT_TEXT_START:
		case WStype_FRAGMENT_BIN_START:
		case WStype_FRAGMENT:
		case WStype_FRAGMENT_FIN:
			break;
	}

}

/* this part is just for fun, it updates a live gui through a websocket :) */
void debugClient(void* param) {
	// ws_client.begin("nope", 1337);
	ws_client.begin("130.215.168.43", 1337);
	DEBUG("Attempting to connect to debug websocket...")

	ws_client.onEvent(webSocketEvent);
	ws_client.setReconnectInterval(1000);

	while(true) {
		ws_client.loop();

		DebugMessage msg;
		if(xQueueReceive(debugQueue, &msg, 0) == pdTRUE) {
			String b64 = base64::encode((const uint8_t*)msg.payload, msg.pldLen);

			char buf[500];
			int n = snprintf(buf, 499, "{\"%s\":\"%s\"}", msg.field, b64.c_str());
			ws_client.sendTXT(buf, n);

			free(msg.field);
			free(msg.payload);
		}

		if(xQueueReceive(poseQueue, &msg, 0) == pdTRUE) {
			String b64 = base64::encode((const uint8_t*)msg.payload, msg.pldLen);

			char buf[500];
			int n = snprintf(buf, 499, "{\"%s\":\"%s\"}", msg.field, b64.c_str());
			ws_client.sendTXT(buf, n);

			free(msg.field);
			free(msg.payload);
		}

		vTaskDelay(5); // we need a small delay here to feed the freeRTOS watchdog timer
	}
	// while(true) {
	// 	vTaskDelay(100);
	// }
}

/* we'll just start all the debugging stuff on the unused core of the esp32, and set up a queue (thread safe) to pass messages to it */
/* this is all part of freeRTOS which is bundled with arduino */
void initDebug() {
    debugQueue = xQueueCreate(500, sizeof(DebugMessage));
	poseQueue = xQueueCreate(10, sizeof(DebugMessage)); // seperate pose queue because otherwise the queue gets clogged up
    xTaskCreatePinnedToCore(debugClient, "WiFi Debug Client", 4000, NULL, 1, NULL, 0);
}