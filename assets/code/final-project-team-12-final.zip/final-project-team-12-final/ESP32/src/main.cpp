#include <Arduino.h>
#include <tinyrpc.h>
#include <shared-functions.h>
#include <IRdecoder.h>
#include <globals.h>
#include <MQTTClient.h>
#include <state.h>
#include <ir_codes.h>
#include <romi-constants.h>
#include <debug.h>
#include <mapping.h>
#include <rtc_wdt.h>

RobotState g_robot;

State_Estop* savedEstopState;

void initRobotState() {
  
  auto irInit = RPC::getSharpDistance().await();
  while(!irInit.valid) {
    delayMicroseconds(1000);
    irInit = RPC::getSharpDistance().await();
    DEBUG("Failed to get valid IR reading!")
  }

  g_robot.irRollingAverage = irInit;
  g_robot.irDistance = irInit;

  auto rfInit = RPC::getHCSR04Distance().await();
  while(!rfInit.valid || rfInit.value > CELL_LENGTH) {
    delayMicroseconds(1000);
    rfInit = RPC::getHCSR04Distance().await();
    DEBUG("Failed to get valid RF reading!")
  }

  g_robot.rfRollingAverage = rfInit;
  g_robot.rfDistance = rfInit;
}

/*
  This grabs the pose estimate, sharpir distance, and HCSR04 distance once per loop, and saves them into the global robot struct.
*/
void updateRobotState() {
  mqtt.update();

  g_robot.pose = RPC::getPoseEstimate().await();
  g_robot.pose.angle = fmod(g_robot.pose.angle, (2*PI)); //should give u better results

  auto irDist = RPC::getSharpDistance().await();
  if(irDist.valid && irDist.value < 50 && irDist.value > 0) {
    g_robot.irDistance = irDist;
    g_robot.irRollingAverage.value = (g_robot.irRollingAverage.value * IR_ROLLING_AVG_WEIGHT) + (g_robot.irDistance.value * (1-IR_ROLLING_AVG_WEIGHT));
  } else {
    g_robot.irDistance.valid = false;
  }

  auto rfDist = RPC::getHCSR04Distance().await();
  if(rfDist.valid) {
    g_robot.rfDistance = rfDist;
    g_robot.rfRollingAverage.value = (g_robot.rfRollingAverage.value * RF_ROLLING_AVG_WEIGHT) + (g_robot.rfDistance.value * (1-RF_ROLLING_AVG_WEIGHT));
  } else {
    g_robot.rfDistance.valid = false;
  }

  // filterState();

  g_robot.beaconPose = RPC::getIRFinderReading().await();

  if(g_robot.beaconPose.points[0].y == 1023) {
    g_robot.beaconPose.valid = false;
  }

  //DEBUG("VALID " + String(g_robot.beaconPose.valid) + ", x " + String(g_robot.beaconPose.points[0].x) + ", y " + String(g_robot.beaconPose.points[0].y))

  UPDATE_DEBUG_POSE((const char*)&g_robot.pose, sizeof(Pose))

  GlobalMapper::updateGlobalMapPosition();
}

IRDecoder decoder(IR_DETECTOR_PIN);
MQTTClient mqtt;

// * This method sets up all of the active key bindings for the remote.
//     mapKeyPress takes a IR button constant,
//     a lambda function with behavior for what happens when you enter the state,
//     and a state where the button press will be recognized. If the state is "STATE_ANY" then no matter what state we are in, the button press will be recognized*/
void setupRemote() { //no need for key presses. We start instantly

  // StateManager::mapKeyPress(ENTER_SAVE, [](){ 
  //   savedEstopState = new State_Estop(StateManager::getActiveStateChain());
  //   StateManager::newChain()
  //     .add(savedEstopState)
  //     .execute();
  // },
  // STATE_ANY);

  // StateManager::mapKeyPress(ENTER_SAVE, []() {
  //   savedEstopState->resumeExecution();
  // },
  // STATE_ESTOP);

  // StateManager::mapKeyPress(LEFT_ARROW, [](){
  //   StateManager::newChain()
  //     .add(new State_Turn(90.0))
  //     .add(new State_Turn(-90.0))
  //     .execute();
  // });

  // StateManager::mapKeyPress(REWIND, [](){
  //   StateManager::newChain()
  //     .add(new State_Explore())
  //     .execute();
  // });

  // StateManager::mapKeyPress(NUM_7, [](){
  //   StateManager::newChain()
  //     .add(new State_IR_Follow())
  //     .execute();
  // });

  // StateManager::mapKeyPress(SETUP_BTN, [](){
  //   StateManager::newChain()
  //     .add(new State_Turn_To_Face(Point<float>(CELL_LENGTH, CELL_LENGTH)))
  //     .execute();
  // });

  // StateManager::mapKeyPress(NUM_0_10, [](){
  //   StateManager::newChain()
  //     .add(new State_Follow_Waypoints(GlobalMapper::navigateToGridCell(Point<int8_t>(0, 0))))
  //     .execute();
  // });

  // StateManager::mapKeyPress(RIGHT_ARROW, [](){
  //   delay(400);
  //   RPC::sendCode(0x00,9);
  //   delay(100);
  //   RPC::sendCode(0x00,9);
  //   delay(100);
  //   RPC::sendCode(0x00,2);
  //   delay(100);
  //   RPC::sendCode(0x00,5);
  //   delay(100);
  //   RPC::sendCode(0x00,2);
  //   //StateManager::resumeIdle();
  // });

  // StateManager::mapKeyPress(NUM_1, [](){
  //   StateManager::newChain()
  //     .add(new State_Outside_Door(180.0)).execute(); //hard coded for testing reasons
  // });

  // StateManager::mapKeyPress(UP_ARROW, [](){
  //   StateManager::newChain()
  //     .add(new State_Turn(90))
  //     .add(new State_Ramp_Wall_Follow())
  //     .add(new State_Capture_Tag())
  //     .execute();
  // });
}

#ifdef RAMP_ROMI
  StateManager::StateChain* constructDefaultChain() {
    auto defaultChain = new StateManager::StateChain();

    defaultChain->add(new State_Turn(90));
    defaultChain->add(new State_Ramp_Wall_Follow());
    defaultChain->add(new State_Capture_Tag());
    defaultChain->add(new State_Idle());

    return defaultChain;
  }
#endif

#ifdef IR_ROMI
  StateManager::StateChain* constructDefaultChain() {
    auto defaultChain = new StateManager::StateChain();

    defaultChain->add(new State_IR_Follow());

    return defaultChain;
  }
#endif

#ifdef DOOR_ROMI
  StateManager::StateChain* constructDefaultChain() {
    auto defaultChain = new StateManager::StateChain();

    defaultChain->add(new State_Wait_For_MQTT());

    return defaultChain;
  }
#endif


void setup() {
  //rtc_wdt_disable(); //unsure about the ramifications of disabling watch dog, so lets leave it alive
  initDebug();
  Serial.begin(115200);
  Serial2.begin(115200);
  DEBUG("Starting main thread on core " + String(xPortGetCoreID()))
  TinyRPC::init(&Serial2);

  setupRemote();
  DEBUG("Mapped All buttons.")

  decoder.init();
  DEBUG("Init. IR Decoder.")
  mqtt.init();
  DEBUG("Init. MQTT Client.")

  GlobalMapper::init();

  initRobotState();

  auto defaultChain = constructDefaultChain();

  DEBUG("Made Idle StateChain.")

  StateManager::setDefaultStateChain(defaultChain);
  DEBUG("Finished setup!")
}

void loop() {
  updateRobotState();
  StateManager::loop();
  StateManager::keyLoop();
}