#pragma once
#include <globals.h>
#include <romi-constants.h>

/* This class deals with mapping the arena. This uses the robots suite of sensors to make discoveries about the arena 
Data about what the robot discovers is also sent over WIFI to our computer in specified payloads*/

#define XPLUS    0b000001
#define XMINUS   0b000010
#define YPLUS    0b000100
#define YMINUS   0b001000
#define PASSABLE 0b010000
#define UNKNOWN  0b100000

class GlobalMapper {
public:
    class Waypoint {
    public:
        Point<float> position;
        Waypoint* next;

        Waypoint(Point<float> p, Waypoint* x) : position(p), next(x) {}

        void freeAll() {
            if(next != nullptr)
                next->freeAll();

            free(this);
        }
    };

    static void updateGlobalMapPosition();
    static Waypoint* navigateToGridCell(Point<int8_t> target);
    static void init();
    static Point<int8_t> getForwardCell();
    static Point<int8_t> calculateGridCellOfPos(Point<float> pos);
    static Point<float> gridPointToGlobalPoint(Point<int8_t> gridPoint);
    static Point<int8_t> getCurrentCell();
    static bool wholeMapExplored();

private:
    static struct MapNode {
        uint8_t information = UNKNOWN;
    } nodes[MAP_X][MAP_Y];

    static Point<int8_t> currentGridCell;

};