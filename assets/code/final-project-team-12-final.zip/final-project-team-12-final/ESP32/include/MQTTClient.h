#pragma once
#include <Arduino.h>
#include <PubSubClient.h>
#include <mqtt.h>

#define NUM_TOPICS 6

/*  This class handles interfacing with the MQTT; sending and recieving data from the broker 
    Messages from specific topics from the MQTT are saved in static variables and are used throughout the states */

class MQTTClient{
    protected:
        static String IRCode;
        static String DoorPosition;
        static bool   IRButtonPressed;
        static bool   RampRomiReady;
        static bool   Door_Victory;
        static bool   IR_Victory;
        static bool   irAlive;
        static bool   rampAlive;
        static bool   doorAlive;
        
        static bool newDataAvailable[NUM_TOPICS];

        static void callback(char* topic, byte *payload, unsigned int length);
        bool publishMQTT(String& str);
    
    public:
        MQTTClient(void);
        
        void init(void);

        void sendMessage(const String& topic, const String& message);
        void update(void);

        String getIRCode(void)            {newDataAvailable[0] = false; return IRCode;}
        String getDoorPosition(void)      {newDataAvailable[1] = false; return DoorPosition;}
        bool isIRButtonPressed(void)      {newDataAvailable[2] = false; return IRButtonPressed;}
        bool isRampRomiReady(void)        {newDataAvailable[3] = false; return RampRomiReady;}
        bool isIRRomiDone(void)           {newDataAvailable[4] = false; return IR_Victory;}
        bool isDoorRomiDone(void)         {newDataAvailable[5] = false; return Door_Victory;}

        bool isDoorRomiAlive(void)         {return doorAlive;}
        bool isIRRomiAlive(void)         { return irAlive;}
        bool isRampRomiAlive(void)         {return rampAlive;}

        bool IRCodeAvailable(void)          {return newDataAvailable[0]; }
        bool doorPositionAvailible(void)    {return newDataAvailable[1]; }
        bool IRButtonAvailable(void)        {return newDataAvailable[2]; }
        bool rampRomiReadyAvailable(void)   {return newDataAvailable[3]; }
        bool isIRRomiAvailable(void)        {return newDataAvailable[4]; }
        bool isDoorRomiAvailable(void)      {return newDataAvailable[5]; }
        bool isAllConnected(void)           {return irAlive && rampAlive && doorAlive;}
        
};