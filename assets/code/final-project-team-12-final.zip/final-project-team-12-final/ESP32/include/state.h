#pragma once
#include <event_timer.h>
#include <globals.h>
#include <apriltagdatum.h>
#include <shared-functions.h>
#include <romi-constants.h>
#include <debug.h>
#include <romi-constants.h>
#include <mapping.h>


/* What are robot is doing at any given time is defined by what state it is in. Each state has 3 different fields main functions: 
begin, which defines behavior when the robot first enters the state,
loop, which defines continuous behavior for when the robot is in the state, returning true will end this loop
end, which defines behavior for when the robot exits the state */

#define IS_STATE_T  \
public:             \
    void begin();   \
    bool loop();    \
    void end();

/* State Manager Class - each state instance has a enum attached to it */

enum States {
    STATE_IDLE,
    STATE_TURN,
    STATE_ESTOP,
    STATE_EXPLORE,
    STATE_MOVETOPOINT,
    STATE_MOVEAHEAD,
    STATE_MOVEADJ,
    STATE_FOLLOW_WP,
    STATE_TURN_TO_FACE,
    STATE_WALL_FOLLOW,
    STATE_DRIVE_FOR,
    STATE_ARC,
    STATE_DRIVE_RAMP,
    STATE_MOTION,
    STATE_DRIVE_TIL_TAG,
    STATE_IR_FOLLOW,
    STATE_OUTSIDE_DOOR,
    STATE_RAMP_WALL_FOLLOW,
    STATE_CAPTURE_TAG,
    STATE_NAVIGATE_TO_DOOR,
    STATE_LEAVE_RAMP,
    State_WAIT_FOR_MQTT,
    STATE_REFINE_POSE,
    STATE_BACKWARDS_WALL_FOLLOW,
    N_STATES
};
#define STATE_ANY N_STATES

class State; // Forward Decl.       

/*  The StateManager is a Queue of states that handles sequencing the robot through the states in the current chain of operation. 
    State instances can be added to the existing chain or combined to make a new StateChain for the robot to execute. */

class StateManager {
public:

    /* implementation of a FIFO Linked-List Queue */
    class StateChain {
    private:
        int length = 0;
        State* first = nullptr;
        State* current = nullptr;
        State* last = nullptr;

        void loop();
        void moveToNextState();
    
    public:
        ~StateChain();

        StateChain& add(State* state);
        StateChain& push(State*);
        void doNow(State* state);

        void execute();

        friend StateManager;
    };

public:
    static void resumeIdle() {
        execute(*idleStateChain);
    }

    /* Map a key to a function */
    static void mapKeyPress(uint8_t key, void (*cb)(), States inState = STATE_ANY);

    /* Call periodically; Handles calling state */
    static void loop();

    /* Call peridically; Handles key processing */
    static void keyLoop();

    static void setDefaultStateChain(StateChain* sc);

    static StateChain& newChain();

    static void execute(StateChain& sc);

    static StateChain& getActiveStateChain();

private:
    static StateChain* currentStateChain;
    static StateChain* idleStateChain;
    static uint8_t activeStateType;

    struct ButtonMapping {
        int16_t button;
        void (*cb)();
    };

    static struct StateKeyMap {
        uint8_t idx;
        struct ButtonMapping map[MAX_BUTTONS_PER_STATE];
    } mappings[N_STATES + 1];
};

/*  A State object defines behavior for what the robot should be doing during its existence 
    The State object acts as a Node in the Linked-List.*/

class State {
public:
    State(uint8_t type) : stateType(type) {}

    virtual void begin() = 0;
    virtual bool loop() = 0;
    virtual void end() = 0;

protected:
    State* next = nullptr;
    uint8_t stateType;

    friend class StateManager::StateChain;
    friend class StateManager;
};

/* Each state is a subclass of State and must provide implementation for the three methods begin(), loop() and end() that belongs to the State class
    IS_STATE_T is a shorthand for the function stubs listed above */

class State_Idle : public State {
    IS_STATE_T

public:
    State_Idle()
        : State(STATE_IDLE) {}
};

class State_Turn : public State {
    IS_STATE_T

public:
    State_Turn(float angle, float speed = 45.0)
        : State(STATE_TURN), angle(angle), angularSpeed(speed) {}

private:
    float angle;
    float angularSpeed;
    float wheelSpeed;
    EventTimer timer;
};

class State_Estop : public State {
    IS_STATE_T

public:
    State_Estop(StateManager::StateChain& sc)
        : State(STATE_ESTOP), savedChain(sc) {}

    void resumeExecution();

private:
    StateManager::StateChain& savedChain;
};

class State_Explore : public State {
    IS_STATE_T

public:
    State_Explore()
        : State(STATE_EXPLORE) {}
};

class State_MoveAhead : public State {
    IS_STATE_T

public:
    State_MoveAhead(float distance, float speed = BASE_SPEED)
        : State(STATE_MOVEAHEAD), distance(distance), speed(speed) {}

private:
    float distance;
    float speed;
    EventTimer timer;
};

class State_MoveToPoint : public State {
    IS_STATE_T

public:
    State_MoveToPoint(Point<float> target, float delta = 10.0)
        : State(STATE_MOVETOPOINT), tgt(target), delta(delta) {}

private:
    Point<float> tgt;
    float delta;
};

class State_IR_Follow : public State {
    IS_STATE_T

    public: 
    State_IR_Follow()
        : State(STATE_IR_FOLLOW) {}

    private:
    Point<int16_t> currPoint;
    int Xerror;
    bool hasSeen;
    void handleIRFollow(IRFinderReading);
    void SendCurrentPositionToMQTT();
};

class State_Ramp_Wall_Follow : public State {
    IS_STATE_T

    public:
    State_Ramp_Wall_Follow()
        : State(STATE_RAMP_WALL_FOLLOW) {}
    
    private:
    const float degreeEpsilon = 2;
    const float rampAngle = 5;
    const float rampSpeed = 7.5;
    bool isClimbing = false;
    bool atTop = false;
    const float xlimit = CELL_LENGTH * 4;

};

class State_Capture_Tag : public State {
    IS_STATE_T

    public:
    State_Capture_Tag()
        : State(STATE_CAPTURE_TAG) {}
    
};

class State_Turn_To_Face : public State {
    IS_STATE_T

    public:
    State_Turn_To_Face(Point<float> tgt, float delta = 1.0)
        : State(STATE_TURN_TO_FACE), tgt(tgt), delta(delta) {};

    private:
        Point<float> tgt;
        float delta;
};

class State_MoveAdj : public State {
    IS_STATE_T

    public:
    State_MoveAdj()
        : State(STATE_MOVEADJ) {}
};

class State_Follow_Waypoints : public State {
    IS_STATE_T

    public:
    State_Follow_Waypoints(GlobalMapper::Waypoint* waypoints)
        : State(STATE_FOLLOW_WP), waypoints(waypoints) {};

    private:
    GlobalMapper::Waypoint* waypoints;
};

class State_Outside_Door : public State {
    IS_STATE_T

    public:
    State_Outside_Door(float victoryAngle)
        : State(STATE_OUTSIDE_DOOR), victoryAngle(victoryAngle) {};

    private:
    bool waitingForOpen = false;
    float victoryAngle;
    float angleDiff;
};

class State_Navigate_To_Door : public State {
    IS_STATE_T

    public:
    State_Navigate_To_Door(Point<int8_t> frontOfDoorCell)
        : State(STATE_NAVIGATE_TO_DOOR), frontOfDoorCell(frontOfDoorCell) {};

    private:
    Point<int8_t> frontOfDoorCell {};
    bool shouldTurn;
};

class State_Wait_For_MQTT: public State {
    IS_STATE_T

    public:
    State_Wait_For_MQTT()
        : State(State_WAIT_FOR_MQTT) {};
};

class State_Leave_Ramp : public State {
    IS_STATE_T

    public:
    State_Leave_Ramp(Point<float> targetCell)
        : State(STATE_LEAVE_RAMP), targetCell(targetCell) {};

    private:
    Point<float> targetCell;
    bool primed = false;
};