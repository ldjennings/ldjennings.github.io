#pragma once
#include <IRdecoder.h>
#include <shared-functions.h>
#include <MQTTClient.h>

/* These are anything that needs to be known globably by the ESP32, but not the Atmega*/

#define IR_DETECTOR_PIN 23

#define WALL_DISTANCE       CELL_LENGTH / 2.0
#define WALL_DISTANCE_RAMP  17.5
#define STOP_DISTANCE       15.0

/* adding D term to wall following would be useful, but we found it unneccesary in practice */

#define WALL_KP 0.42 
#define WALL_KD 0.0
#define WALL_KI 0.0 

/* 512 is the true center of the image, but we mounted the IRFinder to the right of the robot's center, so we adjust the middle to compensate */
#define IR_MIDDLE 412 
#define IR_KP 0.080 


/* Map constants */
#define MAP_Y 3
#define MAP_X 6

#define MAX_BUTTONS_PER_STATE 10

/* MQTT constants*/

#define TOPIC_IR_CODE           "IRCode"
#define TOPIC_DOOR_POSITION     "DoorPosition"
#define TOPIC_BUTTON_PRESSED    "IRButtonPressed"
#define TOPIC_RAMP_READY        "RampRomiReady"
#define TOPIC_DOOR_VICTORY      "Victory"
#define TOPIC_IR_VICTORY        "Victory2"


extern struct RobotState {
    Pose pose;
    DistanceReading irDistance;
    DistanceReading rfDistance;
    IRFinderReading beaconPose;
    DistanceReading rfRollingAverage;
    DistanceReading irRollingAverage;
} g_robot;

extern MQTTClient mqtt;