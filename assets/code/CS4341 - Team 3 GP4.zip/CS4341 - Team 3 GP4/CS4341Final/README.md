# CS4341 Final

Hi there, this is our final files for GP4. In order to run this, you need to have ROS, Gazebo, and turtlebot and other ML dependencies installed in your system. For this, you can follow this tutorial: https://emanual.robotis.com/docs/en/platform/turtlebot3/machine_learning/#machine-learning


After making/compiling with catkin_make, here are the instructions to run it:

1. On one terminal, run below:

```
$ roslaunch turtlebot3_gazebo turtlebot3_stage_cs4341.launch
```

2. On another terminal, run below:

```
$ roslaunch turtlebot3_dqn turtlebot3_dqn_stage_cs4341.launch
```

3. On another terminal, run below:

```
$ roslaunch turtlebot3_dqn result_graph.launch
```


