#!/usr/bin/env python
import rospy

from robot_kinematics.srv import inverse_kinematics, inverse_kinematicsResponse 
from geometry_msgs import Vector3
from math import *


llengths = [1, 1, 1]

def handle_inverse_kinematics(req):
    pose:Vector3 = req.linear_pose
    response:Vector3 = pose

    h = sqrt(pose.x**2 + pose.y**2)

    D = (llengths[1]**2 + llengths[2]**2 - h**2)/(2 *llengths[1] * llengths[2])
    
    response.y = atan2(sqrt(1-D**2), D)
    
    D = pose.x/(pose.x**2 + pose.y **2)
    a = atan2(sqrt(1-D**2), D)

    D = (llengths[1]**2 + h**2 - llengths[2]**2)/(2 *llengths[1] * h**2)
    b = atan2(sqrt(1-D**2), D)
    
    response.x = a - b

    response.z = pose.z - llengths[0]
    
    return inverse_kinematicsResponse(response)

def inverse_kinematics_server():
    rospy.init_node('inverse_kinematics_server')
    s = rospy.Service('inverse_kinematics', inverse_kinematics, handle_inverse_kinematics)
    print("Ready to add two ints.")
    rospy.spin()

if __name__ == "__main__":
    inverse_kinematics_server()
