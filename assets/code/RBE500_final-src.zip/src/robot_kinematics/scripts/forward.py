#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Quaternion, Point, Pose
from sensor_msgs.msg import JointState
from math import sin, cos
import numpy as np
np.set_printoptions(linewidth=1000)

def matrix_to_quaternion(R):
    tr = np.trace(R)
    if tr > 0:
        S = np.sqrt(tr + 1.0) * 2
        qw = 0.25 * S
        qx = (R[2, 1] - R[1, 2]) / S
        qy = (R[0, 2] - R[2, 0]) / S
        qz = (R[1, 0] - R[0, 1]) / S
    elif (R[0, 0] > R[1, 1]) and (R[0, 0] > R[2, 2]):
        S = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        qw = (R[2, 1] - R[1, 2]) / S
        qx = 0.25 * S
        qy = (R[0, 1] + R[1, 0]) / S
        qz = (R[0, 2] + R[2, 0]) / S
    elif R[1, 1] > R[2, 2]:
        S = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        qw = (R[0, 2] - R[2, 0]) / S
        qx = (R[0, 1] + R[1, 0]) / S
        qy = 0.25 * S
        qz = (R[1, 2] + R[2, 1]) / S
    else:
        S = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        qw = (R[1, 0] - R[0, 1]) / S
        qx = (R[0, 2] + R[2, 0]) / S
        qy = (R[1, 2] + R[2, 1]) / S
        qz = 0.25 * S
    q = np.array([qx, qy, qz, qw])
    if q[0] < 0:
        q = -q
    norm_q = q / np.linalg.norm(q)
    return Quaternion(*norm_q)

def calc_fk(theta1, theta2, d3):
    c12 = cos(theta1 + theta2)
    s12 = sin(theta1 + theta2)
    a2 = 1
    a1 = 1
    d1 = 1
    return np.array([[c12,  s12, 0, a2*c12 + a1*cos(theta1)],
                     [s12, -c12, 0, a2*s12 + a1*sin(theta1)],
                     [0,    0, -1, d1 - d3],
                     [0, 0, 0, 1]])


def callback(joints: JointState):
    rospy.loginfo("*"*100)
    theta1, theta2, d3 = tuple(joints.position)
    mat = calc_fk(theta1, theta2, d3)
    rospy.loginfo(f'\n{mat}')
    # Convert to a quaternion because ROS is dumb
    q = matrix_to_quaternion(mat[0:3])
    p = Point(mat[0, 3], mat[1, 3], mat[2, 3])
    pose = Pose(p, q)
    rospy.loginfo(pose)
    pub.publish(pose)
    

    
def listener():
    rospy.loginfo("Initalizing forward kinematics node")
    rospy.init_node('forward_kinematics', anonymous=True)

    rospy.Subscriber("robot/joint_states", JointState, callback)
    global pub
    pub = rospy.Publisher("forward_kinematics", Pose, queue_size=10)

    rospy.spin()

if __name__ == '__main__':
    listener()
