#!/usr/bin/env python
import rospy

from robot_kinematics.srv import inverse_kinematics, inverse_kinematicsResponse 
from geometry_msgs.msg import Pose, Point, Quaternion
from sensor_msgs.msg import JointState
import numpy as np
from math import cos, sin, atan2, sqrt, pi

def calc_fk(theta1, theta2, d3):
    c12 = cos(theta1 + theta2)
    s12 = sin(theta1 + theta2)
    a2 = 1
    a1 = 1
    d1 = 1
    return np.array([[c12,  s12, 0, a2*c12 + a1*cos(theta1)],
                     [s12, -c12, 0, a2*s12 + a1*sin(theta1)],
                     [0,    0, -1, d1 - d3],
                     [0, 0, 0, 1]])

def matrix_to_quaternion(R):
    tr = np.trace(R)
    if tr > 0:
        S = np.sqrt(tr + 1.0) * 2
        qw = 0.25 * S
        qx = (R[2, 1] - R[1, 2]) / S
        qy = (R[0, 2] - R[2, 0]) / S
        qz = (R[1, 0] - R[0, 1]) / S
    elif (R[0, 0] > R[1, 1]) and (R[0, 0] > R[2, 2]):
        S = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        qw = (R[2, 1] - R[1, 2]) / S
        qx = 0.25 * S
        qy = (R[0, 1] + R[1, 0]) / S
        qz = (R[0, 2] + R[2, 0]) / S
    elif R[1, 1] > R[2, 2]:
        S = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        qw = (R[0, 2] - R[2, 0]) / S
        qx = (R[0, 1] + R[1, 0]) / S
        qy = 0.25 * S
        qz = (R[1, 2] + R[2, 1]) / S
    else:
        S = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        qw = (R[1, 0] - R[0, 1]) / S
        qx = (R[0, 2] + R[2, 0]) / S
        qy = (R[1, 2] + R[2, 1]) / S
        qz = 0.25 * S
    q = np.array([qx, qy, qz, qw])
    if q[0] < 0:
        q = -q
    norm_q = q / np.linalg.norm(q)
    return Quaternion(*norm_q)

def are_poses_equal(p1, p2):
    pos1 = p1.position
    pos2 = p2.position
    if isclose(pos1.x, pos2.x) and isclose(pos1.y, pos2.y) and isclose(pos1.z, pos2.z):
        o1 = p1.orientation
        o2 = p2.orientation
        if isclose(o1.x, o2.x) and isclose(o1.y, o2.y) and isclose(o1.z, o2.z) and isclose(o1.w, o2.w):
            return True
    return False


def isclose(n1, n2, tol=0.01):
    return abs(n1 - n2) <= tol


def handle_inverse_kinematics(req):
    pose:Pose = req.state

    p:Point = pose.position
    t1 = [0, 0]
    t2 = [0, 0]
    d1 = 1
    a1 = 1
    a2 = 1
    h = sqrt(p.x**2 + p.y**2)

    try:
        #calculating second rotary joint
        D = (a1**2 + a2**2 - h**2)/(2 * a1 * a2)
        # I'm not quite certain why this requires me to bisect the angle, but it makes the node work.
        t2[0] = atan2(sqrt(1-D**2), D)/2
        t2[1] = -atan2(sqrt(1-D**2), D)/2

        #calculating first rotary joint 
        D = p.x/sqrt(p.x**2 + p.y**2)
        a = atan2(sqrt(1-D**2), D)

        D = (a1**2 + h**2 - a2**2)/(2 *a1 * h)
        b = atan2(sqrt(1-D**2), D)
    
        t1[0] = a - b
        t1[1] = a + b

        d3 = d1 - p.z

        for i in t1:
            for j in t2:
                mat = calc_fk(i, j, d3)
                q = matrix_to_quaternion(mat[0:3])
                p = Point(mat[0, 3], mat[1, 3], mat[2, 3])
                guess = Pose(p, q) 
                #print(f"Guess: theta 1 = {i}, theta 2 = {j}\n{guess}\n")
                if are_poses_equal(pose, guess):
                    joints = JointState()
                    joints.name = ["theta 1", "theta 2", "distance 3"]
                    joints.position = [i, j, d3]
                    return joints
    
    except ValueError as e:
        rospy.loginfo("Caught Math domain error, likely outside of robot's workspace.")

    #print(f"Input pose: \n{pose}\n")

    rospy.loginfo("Unable to find solution for pose.")

def inverse_kinematics_server():
    rospy.init_node('inverse_kinematics_server')
    s = rospy.Service('inverse_kinematics', inverse_kinematics, handle_inverse_kinematics)
    print("\n" + '*'*100)
    print("Ready to calculate joint states.")
    rospy.spin()

if __name__ == "__main__":
    inverse_kinematics_server()
