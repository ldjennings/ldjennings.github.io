#!/usr/bin/env python
import rospy

from robot_kinematics.srv import inverse_kinematics, inverse_kinematicsResponse , velocity_kinematics, ivk, velocity_kinematicsRequest, ivkRequest, ivkResponse, velocity_kinematicsResponse
from geometry_msgs.msg import Pose, Point, Quaternion, Twist, Vector3
from sensor_msgs.msg import JointState
import numpy as np
from math import cos, sin, atan2, sqrt, pi

def jacobian(theta1, theta2):
    c12 = cos(theta1 + theta2)
    s12 = sin(theta1 + theta2)
    a2 = 1
    a1 = 1
    J = np.array([[-a1*sin(theta1)-a2*s12, -a2*s12, 0],
                  [a1*cos(theta1)+a2*c12, a2*c12,   0],
                  [                    0,      0,  -1],
                  [                    0,      0,  0],
                  [                    0,      0,  0],
                  [                    1,      1,  0]])
    return J

def handle_velocity_kinematics(joint: velocity_kinematicsRequest):
    joint = joint.joints
    vels = np.array(joint.velocity)

    theta1, theta2, _ = joint.position
    J = jacobian(theta1, theta2)
    
    ee_vels = J.dot(np.atleast_2d(vels).T).flatten()
    x, y, z, wx, wy, wz = ee_vels
    twist = Twist(Vector3(x, y ,z), Vector3(wx, wy, wz))
    return velocity_kinematicsResponse(twist)

def handle_inverse_vel_kinematics(msg: ivkRequest):
    ee_vel: Twist = msg.ee_vel
    pos: Vector3 = msg.joint_pos
    # pos is the vector of joint positions

    theta1 = pos.x
    theta2 = pos.y

    linear = ee_vel.linear
    ang = ee_vel.angular
    ee_vel_arr = np.array([linear.x, linear.y, linear.z, ang.x, ang.y, ang.z])
    ee_vel_arr = np.atleast_2d(ee_vel_arr).T

    Jinv = np.linalg.pinv(jacobian(theta1, theta2))
    vels = Jinv.dot(ee_vel_arr)

    state = JointState(position=[pos.x, pos.y, pos.z], velocity=vels)
    return ivkResponse(state)

def velocity_kinematics_server():
    rospy.init_node('velocity_kinematics_server')
    # joint to ee
    s = rospy.Service('velocity_kinematics', velocity_kinematics, handle_velocity_kinematics)

    # ee to joint
    s = rospy.Service('inverse_velocity_kinematics', ivk, handle_inverse_vel_kinematics)

    rospy.loginfo("Ready!")
    rospy.spin()

if __name__ == "__main__":
    velocity_kinematics_server()
