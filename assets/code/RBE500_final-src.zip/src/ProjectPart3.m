% Open the data file
joint = '3'
filename = strcat('/home/twb/Documents/repos/rbe500-final-project/joint', joint, '_velocity_log.txt');
fileID = fopen(filename, 'r');


if fileID == -1
    error('File not found.');
end


data = textscan(fileID, '%f %f %f', 'Delimiter', '\t');
fclose(fileID);

lim = 1000;
time = data{1}(1:lim);
reference_position = data{2}(1:lim);
actual_position = data{3}(1:lim);


figure;
plot(time, reference_position, 'b', 'LineWidth', 1.5); % Blue line for reference position
hold on;
plot(time, actual_position, 'r', 'LineWidth', 1.5); % Red line for actual position
hold off;


title(strcat('Reference and Actual Velocity vs Time for Joint ', joint));
xlabel('Time');
ylabel('Velocity');
legend('Reference Velocity', 'Actual Velocity');
grid on;
