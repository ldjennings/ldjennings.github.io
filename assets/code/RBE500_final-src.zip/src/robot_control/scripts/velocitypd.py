#!/usr/bin/env python
import rospy
from robot_control.srv import joint_velocity_control, joint_velocity_controlRequest, ee_y_vel, ee_y_velResponse
from robot_kinematics.srv import ivkRequest
from robot_kinematics.srv import ivk as ivk_srv
from sensor_msgs.msg import JointState
from gazebo_msgs.srv import ApplyJointEffort
from geometry_msgs.msg import Vector3, Twist
import time
from threading import Thread


class PD_Controller:
    def __init__(self, joint_name) -> None:
        self.current_vel = 0
        self.joint_name = joint_name

    def pd_control(self, reference):

        rospy.set_param(f'/vrefs/{self.joint_name}', reference)

        # Assume these will not change during execution
        kp = rospy.get_param(f'/vgains/{self.joint_name}/kp')
        kd = rospy.get_param(f'/vgains/{self.joint_name}/kd')    

        # check that it is valid
        if self.joint_name == 'joint3' and (reference < 0 or reference > 1):
            rospy.logerr(f"Must give valid {self.joint_name} value between 0 and 1 inclusive")

        # Initialize prev_error to be zero
        prev_error = 0
        apply_effort = rospy.ServiceProxy('/gazebo/apply_joint_effort', ApplyJointEffort)

        file = open(f'{self.joint_name}_velocity_log.txt', "w")
        t = rospy.get_rostime().to_sec()
        # run the control loop
        st = time.time()
        start = True
        # only for 30s to not block forever
        while((time.time() - st) < 30):
            reference = rospy.get_param(f'/vrefs/{self.joint_name}')
            error = reference - self.current_vel
            derror = error - prev_error
            # rospy.loginfo(f'{error}, {derror}' )
            dt = 1 if start else (time.time() - apply_time)
            start = False
            effort = error * kp + derror * kd / dt
            sTime = rospy.Time(0,0)
            duration = rospy.Duration(0,100000000)
            apply_time = time.time()
            apply_effort(joint_name=self.joint_name, effort=effort,start_time=sTime, duration=duration)
            rospy.loginfo(f'Applying effort={effort} for referece={reference} and current={self.current_vel}')
            file.write(f"{rospy.get_rostime().to_sec()-t} {reference} {self.current_vel}\n")
            # send the effort command to ROS
            prev_error = error
        file.close()

    def joint_state_callback(self, joint_states: JointState):
        '''
        Constantly reads the current value of the joint states to update a class variable for the current velocity
        '''
        joint = joint_states.velocity[int(self.joint_name[-1])-1]
        self.current_vel = joint


    def run(self):
        rospy.Subscriber("robot/joint_states", JointState, self.joint_state_callback)
        print("\n" + '*'*100)
        print(f"Ready to control {self.joint_name}")






if __name__ == "__main__":
    rospy.set_param('/vgains/joint1/kp', 1)
    rospy.set_param('/vgains/joint1/kd', .15)

    rospy.set_param('/vgains/joint2/kp', 0.25)
    rospy.set_param('/vgains/joint2/kd', .05)

    rospy.set_param('/vgains/joint3/kp', .5)
    rospy.set_param('/vgains/joint3/kd', 0.15)

    server1 = PD_Controller('joint1')
    server2 = PD_Controller('joint2')
    server3 = PD_Controller('joint3')

    rospy.init_node('joint_velocity_control')
    server1.run()
    server2.run()
    server3.run()

    def control_all(srv):
        velocities = srv.velocities
        t1 = Thread(target=server1.pd_control, args=(velocities.x,))
        t2 = Thread(target=server2.pd_control, args=(velocities.y,))
        t3 = Thread(target=server3.pd_control, args=(velocities.z,))

        t1.start()
        t2.start()
        t3.start()

        rospy.loginfo("Joint control terminated")

        return []


    rospy.Service(f'velocity_control', joint_velocity_control, control_all)

    rospy.spin()