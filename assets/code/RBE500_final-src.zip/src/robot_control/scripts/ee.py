#!/usr/bin/env python
import rospy
from robot_control.srv import joint_velocity_control, joint_velocity_controlRequest, ee_y_vel
from robot_kinematics.srv import ivkRequest
from robot_kinematics.srv import ivk as ivk_srv
from sensor_msgs.msg import JointState
from gazebo_msgs.srv import ApplyJointEffort
from geometry_msgs.msg import Vector3, Twist
import time


class EE_Velociy_Control():

    def __init__(self) -> None:
        self.current_positions = None
        rospy.Subscriber("robot/joint_states", JointState, self.joint_state_callback)

    
    def joint_state_callback(self, joint_states: JointState):
        '''
        Constantly reads the current value of the joint states to update a class variable for the current velocity
        '''
        self.current_positions = joint_states.position

    def ee_vel_control(self, srv_request):
        y = srv_request.y_vel
        # Convert the ee velocity to joint velocity with IVK
        # use the current joint positions because WHY NOT

        st = time.time()
        first = True
        # only for 30s to not block forever
        while((time.time() - st) < 30):
            pos = self.current_positions
            pos_vec = Vector3(pos[0], pos[1], pos[2])
            ivk = rospy.ServiceProxy('/inverse_velocity_kinematics', ivk_srv)

            res = ivk.call(Twist(Vector3(0, y, 0), Vector3(0, 0, 0)), pos_vec)
            joint_velocities = res.joint_vels.velocity

            # Now that we have the velocities, use the controller!
            vel_vec = Vector3(joint_velocities[0], joint_velocities[1], joint_velocities[2])
            if first:
                control = rospy.ServiceProxy('/velocity_control', joint_velocity_control)
                control.call(vel_vec)
            else:
                rospy.set_param(f'/vrefs/joint1', vel_vec.x)
                rospy.set_param(f'/vrefs/joint2', vel_vec.y)
                rospy.set_param(f'/vrefs/joint3', vel_vec.z)
            first = False
        return []

    def run(self):
        rospy.Service(f'ee_vel_control', ee_y_vel, self.ee_vel_control)



if __name__ == "__main__":
    rospy.init_node("ee_control")
    ee = EE_Velociy_Control()
    ee.run()

    rospy.spin()