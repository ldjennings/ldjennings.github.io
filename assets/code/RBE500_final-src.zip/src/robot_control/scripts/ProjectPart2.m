% Open the data file
filename = 'joint3_velocity_log.txt'
fileID = fopen(filename, 'r');


if fileID == -1
    error('File not found.');
end


data = textscan(fileID, '%f %f %f');
fclose(fileID);


time = data{1};
reference_position = data{2};
actual_position = data{3};


figure;
plot(time, reference_position, 'b', 'LineWidth', 1.5); % Blue line for reference position
hold on;
plot(time, actual_position, 'r', 'LineWidth', 1.5); % Red line for actual position
hold off;


title('Reference and Actual Velocities vs Time');
xlabel('Time');
ylabel('Velocity');
legend('Reference Velocity', 'Actual Velocity');
grid on;
